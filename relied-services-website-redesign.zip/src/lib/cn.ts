/** Tiny className joiner (keeps the project dependency-free). */
export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

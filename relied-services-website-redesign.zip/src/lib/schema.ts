import { SITE } from "@/content/site";

/** schema.org LocalBusiness (Plumber) — only verified facts, no ratings or addresses invented. */
export function localBusinessJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Plumber",
    name: SITE.name,
    legalName: SITE.legalName,
    url: SITE.url,
    telephone: "+1-470-430-3022",
    email: SITE.email,
    description:
      "Residential and commercial plumbing, emergency plumbing assistance, pipe repair, drain cleaning and water heater installation in Mableton, GA and the Greater Atlanta area.",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Mableton",
      addressRegion: "GA",
      addressCountry: "US",
    },
    areaServed: [
      { "@type": "City", name: "Mableton" },
      { "@type": "AdministrativeArea", name: "Greater Atlanta area, Georgia" },
    ],
    hasMap: SITE.googleProfileUrl,
    sameAs: [SITE.googleProfileUrl],
    image: `${SITE.url}/images/hero-plumber.jpg`,
  };
}

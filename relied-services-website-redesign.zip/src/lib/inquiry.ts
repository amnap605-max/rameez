import { SERVICE_OPTIONS } from "@/content/site";

/**
 * Shared sanitising + validation for the contact form.
 * The same rules run in the browser (instant feedback) and on the server
 * (the real gatekeeper — never trust the client).
 */

export type InquiryInput = {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  service: string;
  preferredDate: string;
  message: string;
};

export type InquiryErrors = Partial<Record<keyof InquiryInput, string>>;

export const EMPTY_INQUIRY: InquiryInput = {
  firstName: "",
  lastName: "",
  phone: "",
  email: "",
  service: "",
  preferredDate: "",
  message: "",
};

const LIMITS = { firstName: 80, lastName: 80, phone: 32, email: 160, service: 120, preferredDate: 10, message: 3000 };

// Strip control characters, trim, and cap length.
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

function clean(value: unknown, max: number, keepNewlines = false) {
  if (typeof value !== "string") return "";
  const stripped = keepNewlines ? value.replace(CONTROL, "") : value.replace(CONTROL, "").replace(/[\r\n]+/g, " ");
  return stripped.trim().slice(0, max);
}

export function sanitizeInquiry(raw: unknown): InquiryInput {
  const r = (raw ?? {}) as Record<string, unknown>;
  return {
    firstName: clean(r.firstName, LIMITS.firstName),
    lastName: clean(r.lastName, LIMITS.lastName),
    phone: clean(r.phone, LIMITS.phone),
    email: clean(r.email, LIMITS.email).toLowerCase(),
    service: clean(r.service, LIMITS.service),
    preferredDate: clean(r.preferredDate, LIMITS.preferredDate),
    message: clean(r.message, LIMITS.message, true),
  };
}

export function validateInquiry(v: InquiryInput): InquiryErrors {
  const errors: InquiryErrors = {};

  if (!v.firstName) errors.firstName = "Please enter your first name.";
  if (!v.lastName) errors.lastName = "Please enter your last name.";

  const digits = v.phone.replace(/\D/g, "");
  if (!v.phone) errors.phone = "Please enter a phone number so we can reach you.";
  else if (!(digits.length === 10 || (digits.length === 11 && digits.startsWith("1"))) || /[^\d\s().+-]/.test(v.phone))
    errors.phone = "Please enter a valid 10-digit phone number.";

  if (!v.email) errors.email = "Please enter your email address.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) errors.email = "Please enter a valid email address.";

  if (!v.service) errors.service = "Please choose the service you need.";
  else if (!(SERVICE_OPTIONS as readonly string[]).includes(v.service))
    errors.service = "Please choose a service from the list.";

  if (v.preferredDate) {
    const valid = /^\d{4}-\d{2}-\d{2}$/.test(v.preferredDate) && !Number.isNaN(Date.parse(v.preferredDate));
    // Allow "today" in any US time zone by comparing against UTC-36h.
    const earliest = new Date(Date.now() - 36 * 3600 * 1000).toISOString().slice(0, 10);
    if (!valid) errors.preferredDate = "Please enter a valid date.";
    else if (v.preferredDate < earliest) errors.preferredDate = "Please choose today or a future date.";
  }

  if (!v.message) errors.message = "Please tell us a little about what you need.";
  else if (v.message.length < 10) errors.message = "Please add a few more details (at least 10 characters).";

  return errors;
}

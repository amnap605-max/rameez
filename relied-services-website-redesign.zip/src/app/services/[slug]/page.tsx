import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { AlertTriangle, CalendarCheck, Check, Phone } from "lucide-react";
import { BookingCta } from "@/components/sections/BookingCta";
import { Button } from "@/components/ui/Button";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { PageHero } from "@/components/sections/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { ReviewCard } from "@/components/sections/ReviewsSection";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ServiceCard } from "@/components/sections/ServiceCard";
import { ServiceIcon } from "@/components/ui/ServiceIcon";
import { JsonLd } from "@/components/JsonLd";
import { REVIEWS } from "@/content/reviews";
import { SERVICES, getService } from "@/content/services";
import { SITE } from "@/content/site";

export function generateStaticParams() {
  return SERVICES.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) return {};
  return {
    title: service.metaTitle,
    description: service.metaDescription,
    alternates: { canonical: `/services/${service.slug}` },
    openGraph: { images: [{ url: service.image, alt: service.imageAlt }] },
  };
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();

  const reviews = REVIEWS.filter((r) => service.reviewIds.includes(r.id));
  const related = service.related.map((s) => getService(s)).filter((s) => !!s);
  const isEmergency = service.slug === "emergency-plumbing";

  return (
    <>
      <PageHero
        eyebrow="Our Services"
        title={service.heroHeadline}
        text={service.heroSub}
        crumbs={[{ label: "Services", href: "/services" }, { label: service.title }]}
      >
        <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
          Book a Service
        </Button>
        <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
          Call {SITE.phoneDisplay}
        </Button>
      </PageHero>

      {/* Overview + image */}
      <section className="bg-white py-20 sm:py-24" aria-labelledby="overview-heading">
        <div className="container-x grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
          <Reveal>
            <h2 id="overview-heading" className="text-3xl font-extrabold sm:text-4xl">
              {service.title} from Relied Services
            </h2>
            <div className="mt-6 space-y-4 text-lg leading-relaxed">
              {service.overview.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>

            <h3 className="mt-10 text-xl font-bold">How we can help</h3>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {service.helpsWith.map((item) => (
                <li key={item} className="flex items-start gap-3 rounded-xl bg-light px-4 py-3.5 font-semibold text-navy ring-1 ring-slate-200/70">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-action">
                    <Check className="size-3 text-white" strokeWidth={3} aria-hidden="true" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>

            {isEmergency && (
              <div className="mt-10 rounded-2xl border border-navy/15 bg-light p-6">
                <h3 className="flex items-center gap-2.5 text-xl font-bold">
                  <AlertTriangle className="size-6 text-action" aria-hidden="true" />
                  While you wait for help
                </h3>
                <ul className="mt-4 list-disc space-y-2 pl-6 leading-relaxed">
                  <li>If water is actively leaking, shutting off the main water valve (or the fixture’s shutoff valve) can help limit damage.</li>
                  <li>If it is safe to do so, move belongings away from the water.</li>
                  <li>If you smell gas, leave the building and call 911 or your gas utility.</li>
                </ul>
              </div>
            )}
          </Reveal>

          <Reveal delay={120}>
            <div className="lg:sticky lg:top-28">
              <div className="relative">
                <div aria-hidden="true" className="absolute -bottom-3 -right-3 h-full w-full rounded-3xl border-2 border-action/70" />
                <div className="relative aspect-[4/5] overflow-hidden rounded-3xl bg-navy shadow-card">
                  <Image
                    src={service.image}
                    alt={service.imageAlt}
                    fill
                    sizes="(min-width: 1024px) 38vw, 90vw"
                    style={{ objectPosition: service.imagePosition }}
                    className="object-cover"
                  />
                </div>
              </div>
              <div className="dark-surface relative mt-8 rounded-2xl bg-navy p-6 text-white shadow-card">
                <span className="grid size-12 place-items-center rounded-xl bg-white/10 text-action">
                  <ServiceIcon name={service.icon} className="size-6" />
                </span>
                <p className="mt-4 font-display text-xl font-extrabold text-white">Need {service.title.toLowerCase()}?</p>
                <p className="mt-1.5 text-sm text-white/80">Call or book online and we will help you get started.</p>
                <div className="mt-5 grid gap-3">
                  <Button href={SITE.phoneHref} icon={<Phone className="size-5" aria-hidden="true" />}>
                    Call {SITE.phoneDisplay}
                  </Button>
                  <Button href={SITE.bookingUrl} variant="light" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
                    Book Service
                  </Button>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* When to call */}
      <section className="bg-light py-20 sm:py-24" aria-labelledby="when-heading">
        <div className="container-x">
          <Reveal>
            <div id="when-heading">
              <SectionHeading eyebrow="When to Call" title={`When to Call About ${service.title}`} />
            </div>
          </Reveal>
          <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {service.callWhen.map((item, i) => (
              <li key={item}>
                <Reveal delay={i * 80} className="h-full">
                  <div className="h-full rounded-2xl bg-white p-6 shadow-card ring-1 ring-slate-200/60">
                    <span className="font-display text-3xl font-extrabold text-action" aria-hidden="true">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <p className="mt-3 font-semibold leading-snug text-navy">{item}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Related testimonials (only when a real one applies) */}
      {reviews.length > 0 && (
        <section className="bg-white py-20 sm:py-24" aria-labelledby="svc-reviews">
          <div className="container-x">
            <Reveal>
              <div id="svc-reviews">
                <SectionHeading eyebrow="Customer Feedback" title="What Customers Say" />
              </div>
            </Reveal>
            <div className={`mx-auto mt-12 grid gap-7 ${reviews.length > 1 ? "md:grid-cols-2" : "max-w-xl"} max-w-5xl`}>
              {reviews.map((r) => (
                <Reveal key={r.id} className="h-full">
                  <ReviewCard review={r} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      <HowItWorks />

      {related.length > 0 && (
        <section className="bg-light py-20 sm:py-24" aria-labelledby="related-heading">
          <div className="container-x">
            <Reveal>
              <div id="related-heading">
                <SectionHeading eyebrow="More Services" title="Other Plumbing Services" />
              </div>
            </Reveal>
            <div className="mt-12 grid gap-7 md:grid-cols-3">
              {related.map((s, i) => (
                <Reveal key={s.slug} delay={i * 90} className="h-full">
                  <ServiceCard service={s} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      <BookingCta
        heading={`Ready to Schedule ${service.title}?`}
        text="Book online or give us a call. Tell us what is going on and we will help you get your plumbing back on track."
      />

      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: service.title,
          serviceType: service.title,
          description: service.metaDescription,
          provider: { "@type": "Plumber", name: SITE.name, telephone: "+1-470-430-3022", url: SITE.url },
          areaServed: { "@type": "AdministrativeArea", name: "Mableton and the Greater Atlanta area, Georgia" },
        }}
      />
    </>
  );
}

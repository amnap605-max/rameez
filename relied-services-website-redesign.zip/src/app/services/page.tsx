import type { Metadata } from "next";
import { CalendarCheck, Check, Phone } from "lucide-react";
import { BookingCta } from "@/components/sections/BookingCta";
import { Button } from "@/components/ui/Button";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { PageHero } from "@/components/sections/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Plumbing Services in Mableton, GA & Greater Atlanta",
  description:
    "Residential plumbing, commercial plumbing, emergency plumbing, pipe repair, water heater installation and drain cleaning in Mableton, GA and the Greater Atlanta area.",
  alternates: { canonical: "/services" },
};

// Additional services listed on the existing online booking page.
const MORE = [
  "General Plumbing Services",
  "Busted Pipe Repair",
  "Repiping Services",
  "Water Meter Repair",
  "Sewer Clog",
  "Water Damage & Restoration",
];

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title="Plumbing Services in Mableton & Greater Atlanta"
        text="Residential and commercial plumbing, from everyday repairs to urgent plumbing issues."
        crumbs={[{ label: "Services" }]}
      >
        <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
          Book a Service
        </Button>
        <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
          Call {SITE.phoneDisplay}
        </Button>
      </PageHero>

      <ServicesSection />

      <section className="bg-white py-16 sm:py-20" aria-labelledby="more-services">
        <div className="container-x">
          <Reveal className="mx-auto max-w-4xl rounded-3xl bg-light p-8 ring-1 ring-slate-200/70 sm:p-12">
            <h2 id="more-services" className="text-2xl font-extrabold sm:text-3xl">
              More Services You Can Request
            </h2>
            <p className="mt-3 text-lg">
              These services are also available to request on our online booking page.
            </p>
            <ul className="mt-7 grid gap-3 sm:grid-cols-2">
              {MORE.map((item) => (
                <li key={item} className="flex items-center gap-3 rounded-xl bg-white px-4 py-3.5 font-bold text-navy shadow-sm ring-1 ring-slate-200/70">
                  <span className="grid size-6 shrink-0 place-items-center rounded-full bg-action">
                    <Check className="size-3.5 text-white" strokeWidth={3} aria-hidden="true" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      <HowItWorks />
      <BookingCta />
    </>
  );
}

import { createHash } from "node:crypto";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { sanitizeInquiry, validateInquiry, type InquiryInput } from "@/lib/inquiry";
import { SITE } from "@/content/site";

export const dynamic = "force-dynamic";

const MIN_FILL_MS = 2500; // humans need at least a couple of seconds to fill the form
const MAX_FILL_MS = 1000 * 60 * 60 * 24;
const PER_IP_LIMIT = 5; // submissions per 15 minutes per visitor
const GLOBAL_LIMIT = 120; // submissions per hour overall (flood guard)

function hashIp(ip: string) {
  return createHash("sha256")
    .update(`${process.env.ADMIN_ACCESS_KEY ?? "relied"}:${ip}`)
    .digest("hex");
}

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);

/**
 * Optional notification channels. The inquiry is ALWAYS saved to the database
 * first; these are extra destinations configured with environment variables:
 *   RESEND_API_KEY + INQUIRY_TO_EMAIL [+ INQUIRY_FROM_EMAIL]  → email via Resend
 *   INQUIRY_WEBHOOK_URL                                       → JSON POST (Zapier, Make, CRM…)
 */
async function notify(data: InquiryInput): Promise<boolean> {
  let delivered = false;
  const subject = `New website inquiry: ${data.service} — ${data.firstName} ${data.lastName}`;
  const text = [
    `Name: ${data.firstName} ${data.lastName}`,
    `Phone: ${data.phone}`,
    `Email: ${data.email}`,
    `Service needed: ${data.service}`,
    `Preferred date: ${data.preferredDate || "—"}`,
    "",
    data.message,
  ].join("\n");

  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.INQUIRY_TO_EMAIL;
  if (apiKey && to) {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        signal: AbortSignal.timeout(8000),
        body: JSON.stringify({
          from: process.env.INQUIRY_FROM_EMAIL ?? `${SITE.name} Website <onboarding@resend.dev>`,
          to: to.split(",").map((s) => s.trim()),
          reply_to: data.email,
          subject,
          text,
          html: `<pre style="font:14px/1.5 system-ui,sans-serif;white-space:pre-wrap">${esc(text)}</pre>`,
        }),
      });
      delivered = delivered || res.ok;
    } catch (err) {
      console.error("Inquiry email failed", err);
    }
  }

  const webhook = process.env.INQUIRY_WEBHOOK_URL;
  if (webhook) {
    try {
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: AbortSignal.timeout(8000),
        body: JSON.stringify({ source: SITE.url, receivedAt: new Date().toISOString(), ...data }),
      });
      delivered = delivered || res.ok;
    } catch (err) {
      console.error("Inquiry webhook failed", err);
    }
  }
  return delivered;
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }

  // --- Spam protection --------------------------------------------------------
  // 1) Honeypot: real visitors never see or fill this field.
  // 2) Timing: the form must have been open for a believable amount of time.
  // Bots get a normal-looking success response so they learn nothing.
  const elapsed = Date.now() - Number(body.startedAt);
  const looksLikeBot =
    (typeof body.company === "string" && body.company.trim() !== "") ||
    !Number.isFinite(elapsed) ||
    elapsed < MIN_FILL_MS ||
    elapsed > MAX_FILL_MS;
  if (looksLikeBot) return Response.json({ ok: true });

  const data = sanitizeInquiry(body);
  const errors = validateInquiry(data);
  if (Object.keys(errors).length > 0) {
    return Response.json({ ok: false, errors }, { status: 400 });
  }

  // 3) Rate limiting by hashed IP (raw IPs are never stored).
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
  const ipHash = hashIp(ip);

  try {
    const [perIp] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(inquiries)
      .where(and(eq(inquiries.ipHash, ipHash), gt(inquiries.createdAt, sql`now() - interval '15 minutes'`)));
    const [overall] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(inquiries)
      .where(gt(inquiries.createdAt, sql`now() - interval '1 hour'`));
    if ((perIp?.n ?? 0) >= PER_IP_LIMIT || (overall?.n ?? 0) >= GLOBAL_LIMIT) {
      return Response.json({ ok: false, error: "Too many requests." }, { status: 429 });
    }

    const [saved] = await db
      .insert(inquiries)
      .values({
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        email: data.email,
        service: data.service,
        preferredDate: data.preferredDate || null,
        message: data.message,
        ipHash,
        userAgent: (request.headers.get("user-agent") ?? "").slice(0, 255),
      })
      .returning({ id: inquiries.id });

    const delivered = await notify(data);
    if (delivered && saved) {
      await db.update(inquiries).set({ notified: true }).where(eq(inquiries.id, saved.id));
    }

    return Response.json({ ok: true });
  } catch (err) {
    console.error("Inquiry save failed", err);
    return Response.json({ ok: false, error: "Server error." }, { status: 500 });
  }
}

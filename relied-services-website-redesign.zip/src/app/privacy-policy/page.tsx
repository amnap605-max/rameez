import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/sections/PageHero";
import { Prose } from "@/components/ui/Prose";
import { LEGAL_UPDATED, SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Relied Services collects, uses and protects information submitted through this website.",
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPage() {
  return (
    <>
      <PageHero title="Privacy Policy" text={`Last updated: ${LEGAL_UPDATED}`} crumbs={[{ label: "Privacy Policy" }]} />
      <section className="bg-white py-16 sm:py-20">
        <div className="container-x">
          <Prose>
            <p>
              {SITE.legalName} (“Relied Services,” “we,” “us”) respects your privacy. This policy explains what
              information we collect through this website, how we use it, and the choices you have.
            </p>

            <h2>Information we collect</h2>
            <p>We collect only the information you choose to give us:</p>
            <ul>
              <li>
                <strong>Contact form:</strong> your first and last name, phone number, email address, the service you
                need, an optional preferred date, and the message you write.
              </li>
              <li>
                <strong>Phone and email:</strong> any information you share when you call {SITE.phoneDisplay} or email{" "}
                <a href={`mailto:${SITE.email}`}>{SITE.email}</a>.
              </li>
              <li>
                <strong>Spam-protection data:</strong> when you submit the form, we keep a one-way (hashed) version of
                your connection address and basic browser information so we can limit abuse. We do not store your raw IP
                address with your inquiry.
              </li>
            </ul>
            <p>We do not collect payment information through this website. Please do not send card numbers or other sensitive information in a message.</p>

            <h2>How we use your information</h2>
            <ul>
              <li>To respond to your inquiry and arrange plumbing service.</li>
              <li>To follow up about the request you submitted.</li>
              <li>To protect the website from spam and misuse.</li>
            </ul>
            <p>We do not sell your personal information, and we do not use it for third-party advertising.</p>

            <h2>Who can see your information</h2>
            <p>
              Your inquiry is stored securely and is available to Relied Services staff. We may use trusted service
              providers (such as website hosting or email delivery) only to operate the website and deliver your
              message to us. We may also disclose information if required by law.
            </p>

            <h2>Third-party services</h2>
            <ul>
              <li>
                <strong>Online booking:</strong> the “Book Service” buttons take you to our online booking page, which is
                operated on our booking platform and governed by that platform’s privacy practices.
              </li>
              <li>
                <strong>Google Maps and Google Business Profile:</strong> the map on this site and our Google links are
                provided by Google and are subject to{" "}
                <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">
                  Google’s Privacy Policy
                </a>
                . Google may set cookies when you interact with the map.
              </li>
            </ul>

            <h2>Retention</h2>
            <p>
              We keep inquiries for as long as needed to respond to you and handle any related service, and we delete
              them when they are no longer needed.
            </p>

            <h2>Your choices</h2>
            <p>
              You may ask us to access, correct or delete the information you submitted by contacting us at{" "}
              <a href={`mailto:${SITE.email}`}>{SITE.email}</a> or {SITE.phoneDisplay}.
            </p>

            <h2>Children</h2>
            <p>This website is intended for adults and is not directed to children under 13.</p>

            <h2>Changes to this policy</h2>
            <p>We may update this policy from time to time. The “last updated” date above shows the latest revision.</p>

            <h2>Contact us</h2>
            <p>
              {SITE.legalName}, {SITE.locationLong}
              <br />
              Phone: <a href={SITE.phoneHref}>{SITE.phoneDisplay}</a>
              <br />
              Email: <a href={`mailto:${SITE.email}`}>{SITE.email}</a>
            </p>
            <p>
              <Link href="/accessibility">Accessibility Statement</Link>
            </p>
          </Prose>
        </div>
      </section>
    </>
  );
}

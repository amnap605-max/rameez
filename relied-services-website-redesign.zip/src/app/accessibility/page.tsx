import type { Metadata } from "next";
import { PageHero } from "@/components/sections/PageHero";
import { Prose } from "@/components/ui/Prose";
import { LEGAL_UPDATED, SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Accessibility Statement",
  description: "Relied Services is committed to making this website accessible to everyone, including people with disabilities.",
  alternates: { canonical: "/accessibility" },
};

export default function AccessibilityPage() {
  return (
    <>
      <PageHero
        title="Accessibility Statement"
        text={`Last updated: ${LEGAL_UPDATED}`}
        crumbs={[{ label: "Accessibility Statement" }]}
      />
      <section className="bg-white py-16 sm:py-20">
        <div className="container-x">
          <Prose>
            <p>
              {SITE.name} wants everyone to be able to use this website, including people who use assistive
              technology. We aim to follow the Web Content Accessibility Guidelines (WCAG) 2.1, Level AA, as a
              standard for our design and content.
            </p>

            <h2>What we do</h2>
            <ul>
              <li>Pages use a clear heading structure and landmarks, and a “Skip to main content” link.</li>
              <li>All menus, forms, accordions, and the before-and-after sliders can be used with a keyboard.</li>
              <li>Form fields have visible labels, required-field indicators, and clear error messages.</li>
              <li>Text and buttons are designed to meet color-contrast guidelines.</li>
              <li>Images include descriptive alternative text, and decorative images are hidden from screen readers.</li>
              <li>Animations are subtle and are reduced for visitors who prefer reduced motion.</li>
              <li>Phone numbers and email addresses are tappable links on mobile devices.</li>
            </ul>

            <h2>Known limitations</h2>
            <p>
              Our online booking page and the embedded Google Map are provided by third parties, so we have limited
              control over their accessibility. If you have trouble with either, you can book or ask for directions by
              phone.
            </p>

            <h2>Need help or want to give feedback?</h2>
            <p>
              If you have difficulty using any part of this website, or you would like information in another format,
              please contact us and we will do our best to help:
            </p>
            <p>
              Phone: <a href={SITE.phoneHref}>{SITE.phoneDisplay}</a>
              <br />
              Email: <a href={`mailto:${SITE.email}`}>{SITE.email}</a>
            </p>
            <p>We welcome your feedback and work to improve accessibility on an ongoing basis.</p>
          </Prose>
        </div>
      </section>
    </>
  );
}

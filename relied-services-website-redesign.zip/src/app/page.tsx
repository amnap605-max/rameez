import type { Metadata } from "next";
import { Hero } from "@/components/sections/Hero";
import { TrustStrip } from "@/components/sections/TrustStrip";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { ProjectsSection } from "@/components/sections/ProjectsSection";
import { AboutSection } from "@/components/sections/AboutSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { ReviewsSection } from "@/components/sections/ReviewsSection";
import { BookingCta } from "@/components/sections/BookingCta";
import { FaqSection } from "@/components/sections/FaqSection";
import { ServiceAreaSection } from "@/components/sections/ServiceAreaSection";
import { ContactSection } from "@/components/sections/ContactSection";

export const metadata: Metadata = {
  title: { absolute: "Relied Services | Plumber in Mableton, GA — Residential & Commercial Plumbing" },
  description:
    "Residential and commercial plumbing in Mableton, GA and the Greater Atlanta area. Emergency plumbing assistance, pipe repair, drain cleaning and water heater installation. Call 470-430-3022 or book online.",
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <ServicesSection />
      <ProjectsSection limit={3} />
      <AboutSection />
      <WhyChooseUs />
      <ReviewsSection />
      <BookingCta />
      <FaqSection limit={5} />
      <ServiceAreaSection />
      <ContactSection idPrefix="home" />
    </>
  );
}

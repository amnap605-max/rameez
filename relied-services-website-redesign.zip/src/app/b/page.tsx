import type { Metadata } from "next";
import {
  BAbout,
  BBooking,
  BContact,
  BFaq,
  BGallery,
  BHero,
  BReviews,
  BServiceArea,
  BServices,
  BTrustStrip,
  BWhyUs,
} from "@/components/sections/variantB";

/**
 * HOMEPAGE CONCEPT B — alternative design direction for client review.
 * Same verified business content as Concept A, different layout language.
 * Not indexed by search engines so it never competes with the live homepage.
 */
export const metadata: Metadata = {
  title: "Design B — Homepage Concept (Client Preview)",
  description: "Alternative homepage concept for Relied Services plumbing.",
  robots: { index: false, follow: false },
};

export default function HomeB() {
  return (
    <>
      <BHero />
      <BTrustStrip />
      <BServices />
      <BGallery />
      <BAbout />
      <BWhyUs />
      <BReviews />
      <BBooking />
      <BFaq />
      <BServiceArea />
      <BContact />
    </>
  );
}

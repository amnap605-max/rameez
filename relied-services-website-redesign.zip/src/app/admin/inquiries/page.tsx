import type { Metadata } from "next";
import { timingSafeEqual } from "node:crypto";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { inquiries } from "@/db/schema";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Inquiries (private)",
  robots: { index: false, follow: false },
};

function keyMatches(provided: string | undefined, expected: string | undefined) {
  if (!provided || !expected) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Private inbox of website inquiries.
 * Open:  /admin/inquiries?key=YOUR_ADMIN_ACCESS_KEY   (value lives in .env)
 */
export default async function InquiriesAdminPage({
  searchParams,
}: {
  searchParams: Promise<{ key?: string | string[] }>;
}) {
  const { key } = await searchParams;
  const provided = Array.isArray(key) ? key[0] : key;
  const expected = process.env.ADMIN_ACCESS_KEY;

  if (!expected) {
    return (
      <section className="container-x py-24">
        <h1 className="text-3xl font-extrabold">Inquiries are not enabled</h1>
        <p className="mt-3">Set the ADMIN_ACCESS_KEY environment variable to enable this private page.</p>
      </section>
    );
  }
  if (!keyMatches(provided, expected)) {
    return (
      <section className="container-x py-24">
        <h1 className="text-3xl font-extrabold">Access restricted</h1>
        <p className="mt-3">This page requires a valid access key.</p>
      </section>
    );
  }

  const rows = await db.select().from(inquiries).orderBy(desc(inquiries.createdAt)).limit(200);

  return (
    <section className="container-x py-14">
      <h1 className="text-3xl font-extrabold">Website Inquiries</h1>
      <p className="mt-2">
        {rows.length} most recent {rows.length === 1 ? "inquiry" : "inquiries"} submitted through the contact form.
      </p>

      {rows.length === 0 ? (
        <p className="mt-10 rounded-xl bg-light p-8">No inquiries yet.</p>
      ) : (
        <ul className="mt-8 space-y-5">
          {rows.map((r) => (
            <li key={r.id} className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-slate-200">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-display text-xl font-extrabold text-navy">
                    {r.firstName} {r.lastName}
                  </p>
                  <p className="text-sm font-semibold text-action">{r.service}</p>
                </div>
                <p className="text-sm text-slate-600">
                  {r.createdAt.toLocaleString("en-US", { timeZone: "America/New_York", dateStyle: "medium", timeStyle: "short" })} ET
                  {r.notified ? " · email/webhook sent" : ""}
                </p>
              </div>
              <dl className="mt-4 grid gap-x-8 gap-y-2 text-sm sm:grid-cols-3">
                <div>
                  <dt className="font-bold text-navy">Phone</dt>
                  <dd>
                    <a href={`tel:${r.phone}`} className="underline">
                      {r.phone}
                    </a>
                  </dd>
                </div>
                <div>
                  <dt className="font-bold text-navy">Email</dt>
                  <dd className="break-all">
                    <a href={`mailto:${r.email}`} className="underline">
                      {r.email}
                    </a>
                  </dd>
                </div>
                <div>
                  <dt className="font-bold text-navy">Preferred date</dt>
                  <dd>{r.preferredDate ?? "—"}</dd>
                </div>
              </dl>
              <p className="mt-4 whitespace-pre-wrap rounded-lg bg-light p-4 text-[0.97rem]">{r.message}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

import { CalendarCheck, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { SITE } from "@/content/site";

export default function NotFound() {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy py-24 text-center text-white sm:py-32">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10" />
      <div className="container-x">
        <p className="font-display text-7xl font-extrabold text-white/20 sm:text-8xl" aria-hidden="true">
          404
        </p>
        <h1 className="mt-2 font-display text-3xl font-extrabold text-white sm:text-5xl">This page has sprung a leak.</h1>
        <div className="mx-auto mt-5 h-1 w-20 rounded-full bg-action" aria-hidden="true" />
        <p className="mx-auto mt-6 max-w-xl text-lg text-white/80">
          We could not find the page you were looking for. Head back home, or contact us and we will help.
        </p>
        <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
          <Button href="/" variant="light" size="lg">
            Back to Home
          </Button>
          <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
            Book a Service
          </Button>
          <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
            Call {SITE.phoneDisplay}
          </Button>
        </div>
      </div>
    </section>
  );
}

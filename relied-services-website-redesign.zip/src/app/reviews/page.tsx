import type { Metadata } from "next";
import { BookingCta } from "@/components/sections/BookingCta";
import { PageHero } from "@/components/sections/PageHero";
import { ReviewsSection } from "@/components/sections/ReviewsSection";

export const metadata: Metadata = {
  title: "Customer Reviews — Relied Services, Mableton GA",
  description:
    "Read what customers say about Relied Services plumbing in Mableton and the Greater Atlanta area, and view or leave a review on Google.",
  alternates: { canonical: "/reviews" },
};

export default function ReviewsPage() {
  return (
    <>
      <PageHero
        eyebrow="Reviews"
        title="Customer Reviews"
        text="Feedback from customers we have served in the Greater Atlanta area."
        crumbs={[{ label: "Reviews" }]}
      />
      <ReviewsSection />
      <BookingCta />
    </>
  );
}

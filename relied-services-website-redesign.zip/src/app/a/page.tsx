import { redirect } from "next/navigation";

/** Alias so Concept A can be shared as /a (the live homepage). */
export default function ConceptA() {
  redirect("/");
}

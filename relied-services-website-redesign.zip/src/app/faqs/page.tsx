import type { Metadata } from "next";
import { BookingCta } from "@/components/sections/BookingCta";
import { FaqSection } from "@/components/sections/FaqSection";
import { JsonLd } from "@/components/JsonLd";
import { PageHero } from "@/components/sections/PageHero";
import { FAQS } from "@/content/faqs";

export const metadata: Metadata = {
  title: "Plumbing FAQs — Relied Services, Mableton GA",
  description:
    "Answers to common questions about Relied Services: plumbing services offered, residential and commercial work, emergency plumbing assistance, scheduling and contact information.",
  alternates: { canonical: "/faqs" },
};

export default function FaqsPage() {
  return (
    <>
      <PageHero
        eyebrow="FAQs"
        title="Plumbing Questions, Answered"
        text="Everything you need to know about our services, scheduling and how to reach us."
        crumbs={[{ label: "FAQs" }]}
      />
      <FaqSection />
      <BookingCta />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }}
      />
    </>
  );
}

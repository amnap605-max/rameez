import type { Metadata } from "next";
import { BeforeAfterGallery } from "@/components/gallery/BeforeAfterGallery";
import { PageHero } from "@/components/sections/PageHero";
import { ProjectsCta } from "@/components/sections/ProjectsSection";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PROJECTS } from "@/content/projects";

export const metadata: Metadata = {
  title: "Projects & Before / After Plumbing Gallery",
  description:
    "Browse the Relied Services before-and-after plumbing project gallery: bathroom and kitchen plumbing, water heaters, pipe and leak repair, drainage and fixtures in Mableton, GA.",
  alternates: { canonical: "/projects" },
};

export default function ProjectsPage() {
  return (
    <>
      <PageHero
        eyebrow="Projects"
        title="Projects & Before / After Gallery"
        text="A portfolio of plumbing improvements, organized by the type of work."
        crumbs={[{ label: "Projects" }]}
      />
      <section className="bg-white py-20 sm:py-24" aria-labelledby="gallery-heading">
        <div className="container-x">
          <Reveal>
            <div id="gallery-heading">
              <SectionHeading
                eyebrow="Our Work"
                title="Real Plumbing Transformations"
                text="See the difference professional plumbing work can make."
              />
            </div>
            <p className="mx-auto mt-5 max-w-2xl text-center text-sm font-medium text-slate-600">
              Drag the divider or use the arrow keys to compare, or switch to side-by-side view. The comparisons below
              are sample placeholders that show how the gallery works — real Relied Services project photos will appear
              here.
            </p>
          </Reveal>
          <div className="mt-12">
            <BeforeAfterGallery items={PROJECTS} filters columns={2} />
          </div>
          <Reveal>
            <ProjectsCta />
          </Reveal>
        </div>
      </section>
    </>
  );
}

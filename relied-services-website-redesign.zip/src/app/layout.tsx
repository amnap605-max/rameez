import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter, Montserrat } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { DesignSwitcher } from "@/components/DesignSwitcher"; // CLIENT PREVIEW ONLY — remove before launch
import { Footer } from "@/components/layout/Footer";
import { MobileActionBar } from "@/components/layout/MobileActionBar";
import { JsonLd } from "@/components/JsonLd";
import { localBusinessJsonLd } from "@/lib/schema";
import { SITE } from "@/content/site";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  display: "swap",
  weight: ["600", "700", "800"],
});

const DESCRIPTION =
  "Relied Services provides residential and commercial plumbing, emergency plumbing assistance, pipe repair, drain cleaning and water heater installation in Mableton, GA and the Greater Atlanta area.";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: "Relied Services | Plumber in Mableton, GA — Residential & Commercial Plumbing",
    template: "%s | Relied Services",
  },
  description: DESCRIPTION,
  applicationName: SITE.name,
  openGraph: {
    type: "website",
    siteName: SITE.name,
    locale: "en_US",
    title: "Relied Services | Plumber in Mableton, GA",
    description: DESCRIPTION,
    images: [{ url: "/images/hero-plumber.jpg", width: 1100, height: 1283, alt: "Relied Services plumber" }],
  },
  twitter: { card: "summary_large_image" },
};

export const viewport: Viewport = {
  themeColor: "#0B1F3A",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${montserrat.variable}`}>
      <body className="antialiased">
        <a
          href="#main"
          className="sr-only z-[100] rounded-lg bg-white px-4 py-3 font-semibold text-navy shadow-lg focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
        >
          Skip to main content
        </a>
        <Header />
        <main id="main" className="pb-[4.75rem] md:pb-0">
          {children}
        </main>
        <Footer />
        <MobileActionBar />
        <DesignSwitcher /> {/* CLIENT PREVIEW ONLY — delete this line before launch */}
        <JsonLd data={localBusinessJsonLd()} />
      </body>
    </html>
  );
}

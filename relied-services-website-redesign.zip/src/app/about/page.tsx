import type { Metadata } from "next";
import { AboutSection } from "@/components/sections/AboutSection";
import { BookingCta } from "@/components/sections/BookingCta";
import { PageHero } from "@/components/sections/PageHero";
import { ServiceAreaSection } from "@/components/sections/ServiceAreaSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";

export const metadata: Metadata = {
  title: "About Relied Services — Mableton, GA Plumbers",
  description:
    "Learn about Relied Services, a Mableton, GA plumbing and water damage restoration company serving residential and commercial clients throughout the Greater Atlanta area.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About Us"
        title="About Relied Services"
        text="A Mableton, Georgia plumbing company serving homes and businesses throughout the Greater Atlanta area."
        crumbs={[{ label: "About" }]}
      />
      <AboutSection full />
      <WhyChooseUs />
      <ServiceAreaSection />
      <BookingCta />
    </>
  );
}

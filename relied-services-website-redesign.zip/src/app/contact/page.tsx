import type { Metadata } from "next";
import { CalendarCheck, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { ContactSection } from "@/components/sections/ContactSection";
import { PageHero } from "@/components/sections/PageHero";
import { ServiceAreaSection } from "@/components/sections/ServiceAreaSection";
import { SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Contact & Book Online — Relied Services, Mableton GA",
  description:
    "Contact Relied Services by phone at 470-430-3022, send a message, or book a plumbing service online. Serving Mableton, GA and the Greater Atlanta area.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Contact Us / Book Online"
        text="Call, send a message, or schedule your plumbing service online."
        crumbs={[{ label: "Contact" }]}
      >
        <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
          Book a Service
        </Button>
        <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
          Call {SITE.phoneDisplay}
        </Button>
      </PageHero>
      <ContactSection idPrefix="page" />
      <ServiceAreaSection />
    </>
  );
}

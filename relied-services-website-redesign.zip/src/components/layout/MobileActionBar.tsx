import { CalendarCheck, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { SITE } from "@/content/site";

/** Sticky call / book bar shown on phones only — the two primary conversion actions. */
export function MobileActionBar() {
  return (
    <div className="dark-surface fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-2.5 border-t border-white/10 bg-navy-deep p-2.5 pb-[calc(0.625rem+env(safe-area-inset-bottom))] md:hidden">
      <Button href={SITE.phoneHref} icon={<Phone className="size-5" aria-hidden="true" />}>
        Call Now
      </Button>
      <Button href={SITE.bookingUrl} variant="light" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
        Book Service
      </Button>
    </div>
  );
}

import Link from "next/link";
import { Clock, ExternalLink, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { SITE } from "@/content/site";
import { SERVICES } from "@/content/services";

const linkClass =
  "inline-flex min-h-9 items-center text-[0.95rem] text-white/75 transition-colors hover:text-white";

const colHeading = "mb-5 flex items-center gap-2.5 font-display text-sm font-bold uppercase tracking-[0.16em] text-white";

function ColTitle({ children }: { children: string }) {
  return (
    <h2 className={colHeading}>
      <span className="h-[3px] w-5 rounded-full bg-action" aria-hidden="true" />
      {children}
    </h2>
  );
}

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="dark-surface border-t-4 border-action bg-navy-deep text-white">
      <div className="container-x grid gap-12 py-16 sm:grid-cols-2 lg:grid-cols-[1.35fr_1fr_1fr_1.25fr] lg:gap-10">
        {/* Brand */}
        <div>
          <Link href="/" aria-label="Relied Services — home" className="inline-block">
            <Logo />
          </Link>
          <p className="mt-5 max-w-sm text-[0.95rem] leading-relaxed text-white/75">
            Residential and commercial plumbing for {SITE.serviceArea}: repairs, installations, drain cleaning,
            water heaters, and emergency plumbing assistance.
          </p>
          <a
            href={SITE.googleProfileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-lg border border-white/25 px-4 text-sm font-semibold text-white transition-colors hover:border-white hover:bg-white/10"
          >
            <MapPin className="size-4 text-action" aria-hidden="true" />
            Google Business Profile
            <ExternalLink className="size-3.5 opacity-70" aria-hidden="true" />
            <span className="sr-only">(opens in a new tab)</span>
          </a>
        </div>

        {/* Services */}
        <nav aria-label="Services">
          <ColTitle>Services</ColTitle>
          <ul>
            {SERVICES.map((s) => (
              <li key={s.slug}>
                <Link href={`/services/${s.slug}`} className={linkClass}>
                  {s.title}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Company */}
        <nav aria-label="Company">
          <ColTitle>Company</ColTitle>
          <ul>
            {[
              ["Home", "/"],
              ["About Us", "/about"],
              ["Projects / Before & After", "/projects"],
              ["Customer Reviews", "/reviews"],
              ["FAQs", "/faqs"],
              ["Contact Us", "/contact"],
            ].map(([label, href]) => (
              <li key={href}>
                <Link href={href} className={linkClass}>
                  {label}
                </Link>
              </li>
            ))}
            <li>
              <a href={SITE.bookingUrl} target="_blank" rel="noopener noreferrer" className={linkClass}>
                Book Online
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            </li>
          </ul>
        </nav>

        {/* Contact */}
        <div>
          <ColTitle>Contact</ColTitle>
          <ul className="space-y-4 text-[0.95rem]">
            <li>
              <a href={SITE.phoneHref} className="flex items-start gap-3 text-white transition-colors hover:text-white/80">
                <Phone className="mt-0.5 size-5 shrink-0 text-action" aria-hidden="true" />
                <span>
                  <span className="block text-xs font-semibold uppercase tracking-wider text-white/60">Call us</span>
                  <span className="text-lg font-bold">{SITE.phoneDisplay}</span>
                </span>
              </a>
            </li>
            <li>
              <a href={`mailto:${SITE.email}`} className="flex items-start gap-3 text-white/85 transition-colors hover:text-white">
                <Mail className="mt-0.5 size-5 shrink-0 text-action" aria-hidden="true" />
                <span className="break-all">{SITE.email}</span>
              </a>
            </li>
            <li className="flex items-start gap-3 text-white/85">
              <MapPin className="mt-0.5 size-5 shrink-0 text-action" aria-hidden="true" />
              <span>
                {SITE.locationShort}
                <span className="block text-sm text-white/65">Serving the Greater Atlanta area</span>
              </span>
            </li>
            <li className="flex items-start gap-3 text-white/85">
              <Clock className="mt-0.5 size-5 shrink-0 text-action" aria-hidden="true" />
              <span className="text-sm leading-relaxed">
                {SITE.hours.map((h) => (
                  <span key={h.days} className="block">
                    {h.days}: {h.time}
                  </span>
                ))}
              </span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x flex flex-col items-start justify-between gap-3 py-6 text-sm text-white/65 sm:flex-row sm:items-center">
          <p>
            © {year} {SITE.legalName}. All Rights Reserved.
          </p>
          <ul className="flex flex-wrap gap-x-6 gap-y-1">
            <li>
              <Link href="/privacy-policy" className="inline-flex min-h-9 items-center hover:text-white">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/accessibility" className="inline-flex min-h-9 items-center hover:text-white">
                Accessibility Statement
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}

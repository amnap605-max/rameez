"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { CalendarCheck, ChevronDown, Menu, Phone, X } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { Button } from "@/components/ui/Button";
import { ServiceIcon } from "@/components/ui/ServiceIcon";
import { NAV_LINKS, SITE } from "@/content/site";
import { SERVICES } from "@/content/services";
import { cn } from "@/lib/cn";

export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  // Close menus whenever the route changes
  useEffect(() => {
    setMobileOpen(false);
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock page scroll while the mobile menu is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  // Close the desktop dropdown on outside click / Escape
  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  return (
    <header
      className={cn(
        "dark-surface sticky top-0 z-50 border-b border-white/10 bg-navy transition-shadow duration-300",
        scrolled && "shadow-[0_10px_30px_-14px_rgba(0,0,0,0.6)]",
      )}
    >
      <div className="container-x flex h-[4.5rem] items-center justify-between gap-4">
        <Link href="/" aria-label="Relied Services — home" className="shrink-0">
          <Logo />
        </Link>

        {/* Desktop navigation */}
        <nav aria-label="Main navigation" className="hidden items-center gap-1 xl:flex">
          {NAV_LINKS.map((item) =>
            "hasMenu" in item ? (
              <div
                key={item.href}
                ref={menuRef}
                className="relative"
                onMouseEnter={() => setMenuOpen(true)}
                onMouseLeave={() => setMenuOpen(false)}
                onBlur={(e) => {
                  if (!e.currentTarget.contains(e.relatedTarget as Node)) setMenuOpen(false);
                }}
              >
                <button
                  type="button"
                  aria-expanded={menuOpen}
                  aria-haspopup="true"
                  aria-controls="services-menu"
                  onClick={() => setMenuOpen((v) => !v)}
                  className={cn(
                    "relative flex items-center gap-1.5 rounded-md px-3.5 py-2 text-[0.95rem] font-semibold text-white/90 transition-colors hover:text-white",
                    isActive(item.href) && "text-white",
                  )}
                >
                  {item.label}
                  <ChevronDown
                    className={cn("size-4 transition-transform duration-200", menuOpen && "rotate-180")}
                    aria-hidden="true"
                  />
                  {isActive(item.href) && (
                    <span className="absolute inset-x-3.5 -bottom-[1.1rem] h-[3px] rounded-full bg-action" aria-hidden="true" />
                  )}
                </button>
                <div
                  id="services-menu"
                  className={cn(
                    "absolute left-1/2 top-full w-[22rem] -translate-x-1/2 pt-3 transition duration-200",
                    menuOpen ? "visible translate-y-0 opacity-100" : "invisible -translate-y-1 opacity-0",
                  )}
                >
                  <div className="rounded-xl bg-white p-2 shadow-2xl ring-1 ring-black/5">
                    <Link
                      href="/services"
                      className="flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-bold text-navy hover:bg-light focus-visible:bg-light"
                      style={{ outlineColor: "#163A63" }}
                    >
                      All Services
                      <span className="text-xs font-semibold text-action">View all</span>
                    </Link>
                    <div className="my-1 h-px bg-slate-200" aria-hidden="true" />
                    {SERVICES.map((s) => (
                      <Link
                        key={s.slug}
                        href={`/services/${s.slug}`}
                        className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-[0.95rem] font-semibold text-navy transition-colors hover:bg-light focus-visible:bg-light"
                        style={{ outlineColor: "#163A63" }}
                      >
                        <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-navy text-action">
                          <ServiceIcon name={s.icon} className="size-[1.1rem]" />
                        </span>
                        {s.title}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive(item.href) ? "page" : undefined}
                className={cn(
                  "relative rounded-md px-3.5 py-2 text-[0.95rem] font-semibold text-white/90 transition-colors hover:text-white",
                  isActive(item.href) && "text-white",
                )}
              >
                {item.label}
                {isActive(item.href) && (
                  <span className="absolute inset-x-3.5 -bottom-[1.1rem] h-[3px] rounded-full bg-action" aria-hidden="true" />
                )}
              </Link>
            ),
          )}
        </nav>

        <div className="flex items-center gap-2.5">
          <Button
            href={SITE.phoneHref}
            size="sm"
            icon={<Phone className="size-4" aria-hidden="true" />}
            className="hidden xl:inline-flex"
          >
            Call Now: {SITE.phoneDisplay}
          </Button>
          <Button
            href={SITE.bookingUrl}
            variant="light"
            size="sm"
            icon={<CalendarCheck className="size-4" aria-hidden="true" />}
            className="hidden xl:inline-flex"
          >
            Book Service
          </Button>

          {/* Tablet / mobile controls */}
          <a
            href={SITE.phoneHref}
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-action px-3.5 text-sm font-bold text-white transition-colors hover:bg-action-dark xl:hidden"
            aria-label={`Call Relied Services at ${SITE.phoneDisplay}`}
          >
            <Phone className="size-[1.1rem]" aria-hidden="true" />
            <span className="hidden sm:inline">Call Now</span>
          </a>
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-menu"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            className="grid size-11 place-items-center rounded-lg border border-white/25 text-white transition-colors hover:bg-white/10 xl:hidden"
          >
            {mobileOpen ? <X className="size-6" aria-hidden="true" /> : <Menu className="size-6" aria-hidden="true" />}
          </button>
        </div>
      </div>

      {/* Mobile menu panel */}
      <div
        id="mobile-menu"
        className={cn(
          "overflow-hidden border-t border-white/10 bg-navy-deep transition-[max-height,opacity,visibility] duration-300 ease-out xl:hidden",
          mobileOpen ? "visible max-h-[calc(100dvh-4.5rem)] opacity-100" : "invisible max-h-0 opacity-0",
        )}
      >
        <nav
          aria-label="Mobile navigation"
          className="container-x max-h-[calc(100dvh-4.5rem)] overflow-y-auto pb-8 pt-3"
        >
          <ul className="divide-y divide-white/10">
            {NAV_LINKS.map((item) =>
              "hasMenu" in item ? (
                <li key={item.href}>
                  <button
                    type="button"
                    aria-expanded={mobileServicesOpen}
                    aria-controls="mobile-services"
                    onClick={() => setMobileServicesOpen((v) => !v)}
                    className="flex min-h-14 w-full items-center justify-between text-left text-lg font-semibold text-white"
                  >
                    {item.label}
                    <ChevronDown
                      className={cn("size-5 transition-transform duration-200", mobileServicesOpen && "rotate-180")}
                      aria-hidden="true"
                    />
                  </button>
                  <div
                    id="mobile-services"
                    className={cn(
                      "grid transition-[grid-template-rows] duration-300",
                      mobileServicesOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                    )}
                  >
                    <ul className="overflow-hidden" inert={!mobileServicesOpen}>
                      <li>
                        <Link href="/services" className="flex min-h-12 items-center pl-3 text-base font-semibold text-white/90">
                          All Services
                        </Link>
                      </li>
                      {SERVICES.map((s) => (
                        <li key={s.slug}>
                          <Link
                            href={`/services/${s.slug}`}
                            className="flex min-h-12 items-center gap-3 pl-3 text-base text-white/85 hover:text-white"
                          >
                            <ServiceIcon name={s.icon} className="size-[1.1rem] text-action" />
                            {s.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </li>
              ) : (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isActive(item.href) ? "page" : undefined}
                    className={cn(
                      "flex min-h-14 items-center text-lg font-semibold text-white/90 hover:text-white",
                      isActive(item.href) && "text-white",
                    )}
                  >
                    {isActive(item.href) && <span className="mr-3 h-5 w-1 rounded-full bg-action" aria-hidden="true" />}
                    {item.href === "/projects" ? "Projects / Before & After" : item.label}
                  </Link>
                </li>
              ),
            )}
          </ul>
          <div className="mt-6 grid gap-3">
            <Button href={SITE.phoneHref} size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
              Call Now: {SITE.phoneDisplay}
            </Button>
            <Button
              href={SITE.bookingUrl}
              variant="light"
              size="lg"
              icon={<CalendarCheck className="size-5" aria-hidden="true" />}
            >
              Book Service
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}

"use client";

import Image from "next/image";
import { useState } from "react";
import { Bath, Camera, Check, ChevronsLeftRight, CookingPot, Droplets, Flame, ShowerHead, Wrench } from "lucide-react";
import type { ProjectIcon, ProjectImage } from "@/content/projects";

const ICONS = {
  bath: Bath,
  kitchen: CookingPot,
  heater: Flame,
  pipe: Wrench,
  drain: Droplets,
  fixture: ShowerHead,
} as const;

const SIZES = "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw";

type PanelProps = { kind: "before" | "after"; image?: ProjectImage; icon: ProjectIcon };

/** One side of a comparison: a real photo, or a clearly-labelled sample placeholder. */
function Panel({ kind, image, icon }: PanelProps) {
  if (image) {
    return <Image src={image.src} alt={image.alt} fill sizes={SIZES} className="object-cover" draggable={false} />;
  }
  const Icon = ICONS[icon];
  if (kind === "before") {
    return (
      <div className="bg-hatch absolute inset-0 grid place-items-center bg-[#d5dce6]">
        <div className="flex flex-col items-center px-6 text-center text-slate-700">
          <span className="grid size-[4.5rem] place-items-center rounded-full border-2 border-dashed border-slate-500/70 bg-white/60">
            <Icon className="size-8" aria-hidden="true" />
          </span>
          <span className="mt-3 flex items-center gap-1.5 text-sm font-bold">
            <Camera className="size-4" aria-hidden="true" /> Sample photo area
          </span>
          <span className="mt-0.5 text-xs font-medium">Replace with a real “before” photo</span>
        </div>
      </div>
    );
  }
  return (
    <div className="absolute inset-0 grid place-items-center bg-gradient-to-br from-navy-mid to-navy">
      <div className="flex flex-col items-center px-6 text-center text-white">
        <span className="relative grid size-[4.5rem] place-items-center rounded-full border-2 border-white/35 bg-white/10">
          <Icon className="size-8" aria-hidden="true" />
          <span className="absolute -right-1 -top-1 grid size-6 place-items-center rounded-full bg-action ring-2 ring-navy-mid">
            <Check className="size-3.5" strokeWidth={3} aria-hidden="true" />
          </span>
        </span>
        <span className="mt-3 flex items-center gap-1.5 text-sm font-bold">
          <Camera className="size-4" aria-hidden="true" /> Sample photo area
        </span>
        <span className="mt-0.5 text-xs font-medium text-white/80">Replace with a real “after” photo</span>
      </div>
    </div>
  );
}

const labelClass =
  "pointer-events-none absolute top-3 z-20 rounded-md px-2.5 py-1 text-[0.7rem] font-extrabold tracking-[0.16em] shadow-md";

type Props = {
  title: string;
  icon: ProjectIcon;
  before?: ProjectImage;
  after?: ProjectImage;
  mode?: "slider" | "side";
};

/**
 * Interactive before/after comparison.
 *  - "slider": drag, tap or use arrow keys (native range input = fully accessible)
 *  - "side":   aligned side-by-side images with BEFORE / AFTER labels
 */
export function BeforeAfterSlider({ title, icon, before, after, mode = "slider" }: Props) {
  const [pos, setPos] = useState(50);

  if (mode === "side") {
    return (
      <div className="grid grid-cols-2 gap-2">
        {(["before", "after"] as const).map((kind) => (
          <figure key={kind} className="relative aspect-[3/4] overflow-hidden rounded-xl bg-slate-200 sm:aspect-[4/5]">
            <Panel kind={kind} image={kind === "before" ? before : after} icon={icon} />
            <figcaption
              className={`${labelClass} left-3 ${kind === "before" ? "bg-white text-navy" : "bg-action text-white"}`}
            >
              {kind === "before" ? "BEFORE" : "AFTER"}
            </figcaption>
          </figure>
        ))}
      </div>
    );
  }

  return (
    <div className="relative aspect-[4/3] select-none overflow-hidden rounded-xl bg-slate-200 focus-within:ring-4 focus-within:ring-navy-mid/50">
      {/* AFTER — base layer */}
      <Panel kind="after" image={after} icon={icon} />
      {/* BEFORE — clipped to the left of the divider */}
      <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <Panel kind="before" image={before} icon={icon} />
      </div>

      <span className={`${labelClass} left-3 bg-white text-navy`}>BEFORE</span>
      <span className={`${labelClass} right-3 bg-action text-white`}>AFTER</span>

      {/* Divider + handle */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 z-10 w-[3px] -translate-x-1/2 bg-white shadow-[0_0_12px_rgba(0,0,0,0.35)]"
        style={{ left: `${pos}%` }}
      >
        <span className="absolute left-1/2 top-1/2 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-navy shadow-lg ring-4 ring-navy/20">
          <ChevronsLeftRight className="size-5" />
        </span>
      </div>

      <input
        type="range"
        min={0}
        max={100}
        step={1}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-label={`Before and after comparison: ${title}. Use the left and right arrow keys to move the divider.`}
        aria-valuetext={`${pos}% before, ${100 - pos}% after`}
        className="absolute inset-0 z-30 h-full w-full cursor-ew-resize opacity-0"
        style={{ touchAction: "pan-y" }}
      />
    </div>
  );
}

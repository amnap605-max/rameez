"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowRight, Columns2, Info, SlidersHorizontal } from "lucide-react";
import { BeforeAfterSlider } from "@/components/gallery/BeforeAfterSlider";
import { getService } from "@/content/services";
import { PROJECT_CATEGORIES, type Project } from "@/content/projects";
import { cn } from "@/lib/cn";

function ProjectCard({ project }: { project: Project }) {
  const [mode, setMode] = useState<"slider" | "side">("slider");
  const isSample = project.isSample ?? !(project.before && project.after);
  const service = getService(project.serviceSlug);

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-slate-200/70 transition duration-300 hover:-translate-y-1 hover:shadow-card-hover">
      <div className="p-3 pb-0">
        <BeforeAfterSlider
          title={project.title}
          icon={project.icon}
          before={project.before}
          after={project.after}
          mode={mode}
        />
      </div>

      <div className="flex flex-1 flex-col p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="rounded-full bg-light px-3 py-1 text-xs font-bold uppercase tracking-wider text-navy-mid">
            {project.category}
          </span>
          <div role="group" aria-label={`Comparison view for ${project.title}`} className="flex rounded-lg bg-light p-1">
            {(
              [
                ["slider", "Slider", SlidersHorizontal],
                ["side", "Side by Side", Columns2],
              ] as const
            ).map(([value, label, Icon]) => (
              <button
                key={value}
                type="button"
                aria-pressed={mode === value}
                onClick={() => setMode(value)}
                className={cn(
                  "flex min-h-9 items-center gap-1.5 rounded-md px-2.5 text-xs font-bold transition-colors",
                  mode === value ? "bg-navy text-white shadow-sm" : "text-navy hover:bg-white",
                )}
              >
                <Icon className="size-3.5" aria-hidden="true" />
                {label}
              </button>
            ))}
          </div>
        </div>

        <h3 className="mt-4 text-xl font-bold">{project.title}</h3>
        <p className="mt-2 text-[0.95rem] leading-relaxed text-body">{project.caption}</p>

        {isSample && (
          <p className="mt-4 flex items-start gap-2 rounded-lg border border-navy-mid/15 bg-light px-3 py-2.5 text-xs font-semibold leading-snug text-navy-mid">
            <Info className="mt-px size-4 shrink-0" aria-hidden="true" />
            Sample placeholder — not a completed Relied Services project.
          </p>
        )}

        {service && (
          <Link
            href={`/services/${service.slug}`}
            className="mt-auto inline-flex items-center gap-2 pt-5 font-bold text-action"
          >
            About {service.title}
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </Link>
        )}
      </div>
    </article>
  );
}

type Props = {
  items: Project[];
  filters?: boolean;
  columns?: 2 | 3;
};

export function BeforeAfterGallery({ items, filters = false, columns = 3 }: Props) {
  const [category, setCategory] = useState<string>("All");
  const categories = ["All", ...PROJECT_CATEGORIES.filter((c) => items.some((i) => i.category === c))];
  const shown = category === "All" ? items : items.filter((i) => i.category === category);

  return (
    <div>
      {filters && (
        <div className="mb-10">
          <div role="group" aria-label="Filter projects by category" className="flex flex-wrap justify-center gap-2.5">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={category === c}
                onClick={() => setCategory(c)}
                className={cn(
                  "min-h-11 rounded-full border-2 px-5 text-sm font-bold transition-colors",
                  category === c
                    ? "border-navy bg-navy text-white"
                    : "border-slate-300 bg-white text-navy hover:border-navy",
                )}
              >
                {c}
              </button>
            ))}
          </div>
          <p className="sr-only" role="status" aria-live="polite">
            Showing {shown.length} {shown.length === 1 ? "project" : "projects"}
          </p>
        </div>
      )}

      <div className={cn("grid gap-7 sm:grid-cols-2", columns === 3 ? "lg:grid-cols-3" : "lg:grid-cols-2")}>
        {shown.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </div>
  );
}

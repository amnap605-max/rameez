import { cn } from "@/lib/cn";

/**
 * Clean text-based logo (droplet mark + wordmark). The original logo file
 * could not be retrieved from the current site, so this is a faithful,
 * easily-replaced stand-in: swap this component for the owner's logo image.
 */
export function Logo({ tone = "light", className }: { tone?: "light" | "dark"; className?: string }) {
  const onDark = tone === "light";
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <svg viewBox="0 0 40 48" className="h-9 w-[30px] shrink-0" aria-hidden="true">
        <path
          d="M20 2C20 2 4 20.5 4 31a16 16 0 0 0 32 0C36 20.5 20 2 20 2Z"
          fill={onDark ? "#FFFFFF" : "#0B1F3A"}
        />
        <path
          d="M10.5 32.5c3-2.8 6-2.8 9.5 0s6.5 2.8 9.5 0"
          fill="none"
          stroke="#D9272E"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M12 38.5c2.7-2.2 5.3-2.2 8 0s5.3 2.2 8 0"
          fill="none"
          stroke={onDark ? "#163A63" : "#FFFFFF"}
          strokeWidth="2.4"
          strokeLinecap="round"
        />
      </svg>
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.45rem] font-extrabold tracking-[0.04em]",
            onDark ? "text-white" : "text-navy",
          )}
        >
          RELIED
        </span>
        <span className="mt-1 flex items-center gap-2">
          <span className="h-[3px] w-4 rounded-full bg-action" aria-hidden="true" />
          <span
            className={cn(
              "font-display text-[0.62rem] font-bold tracking-[0.34em]",
              onDark ? "text-white/85" : "text-navy-mid",
            )}
          >
            SERVICES
          </span>
        </span>
      </span>
      <span className="sr-only">Relied Services</span>
    </span>
  );
}

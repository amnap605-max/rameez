import { Building2, Droplets, Flame, House, Siren, Wrench } from "lucide-react";
import type { ServiceIcon as ServiceIconKey } from "@/content/services";

const MAP = {
  home: House,
  building: Building2,
  siren: Siren,
  pipe: Wrench,
  flame: Flame,
  drain: Droplets,
} as const;

export function ServiceIcon({ name, className }: { name: ServiceIconKey; className?: string }) {
  const Icon = MAP[name];
  return <Icon className={className} aria-hidden="true" />;
}

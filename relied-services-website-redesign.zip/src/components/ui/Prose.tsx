import type { ReactNode } from "react";

/** Readable long-form typography for legal pages (no plugin required). */
export function Prose({ children }: { children: ReactNode }) {
  return (
    <div
      className="mx-auto max-w-3xl text-[1.05rem] leading-relaxed
        [&_a]:font-semibold [&_a]:text-navy [&_a]:underline [&_a]:decoration-action [&_a]:decoration-2 [&_a]:underline-offset-4
        [&_h2]:mt-12 [&_h2]:text-2xl [&_h2]:font-extrabold [&_h2]:sm:text-3xl
        [&_h3]:mt-8 [&_h3]:text-xl [&_h3]:font-bold
        [&_li]:mt-2 [&_p]:mt-4 [&_ul]:mt-4 [&_ul]:list-disc [&_ul]:pl-6
        [&_strong]:text-navy"
    >
      {children}
    </div>
  );
}

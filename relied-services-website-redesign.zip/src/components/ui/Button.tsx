import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "navy" | "light" | "outlineLight" | "outlineNavy" | "ghostLight";
type Size = "sm" | "md" | "lg";

const base =
  "inline-flex items-center justify-center gap-2 rounded-lg font-semibold leading-tight transition duration-200 ease-out active:translate-y-px text-center";

const variants: Record<Variant, string> = {
  primary: "bg-action text-white shadow-[0_8px_20px_-8px_rgba(217,39,46,0.7)] hover:bg-action-dark hover:shadow-[0_10px_24px_-8px_rgba(217,39,46,0.8)]",
  navy: "bg-navy text-white hover:bg-navy-mid",
  light: "bg-white text-navy shadow-sm hover:bg-light",
  outlineLight: "border-2 border-white/40 text-white hover:border-white hover:bg-white/10",
  outlineNavy: "border-2 border-navy text-navy hover:bg-navy hover:text-white",
  ghostLight: "text-white/90 underline-offset-4 hover:text-white hover:underline",
};

const sizes: Record<Size, string> = {
  sm: "min-h-10 px-4 py-2 text-sm",
  md: "min-h-12 px-6 py-3 text-base",
  lg: "min-h-14 px-7 py-3.5 text-base sm:text-[1.0625rem]",
};

type Props = {
  href: string;
  children: ReactNode;
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  iconRight?: ReactNode;
  className?: string;
  ariaLabel?: string;
};

/**
 * One button component for the whole site. External links (booking page,
 * Google) open in a new tab; tel:/mailto: links use plain anchors.
 */
export function Button({
  href,
  children,
  variant = "primary",
  size = "md",
  icon,
  iconRight,
  className,
  ariaLabel,
}: Props) {
  const classes = cn(base, variants[variant], sizes[size], className);
  const inner = (
    <>
      {icon}
      <span>{children}</span>
      {iconRight}
    </>
  );

  if (/^https?:\/\//.test(href)) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={classes} aria-label={ariaLabel}>
        {inner}
        <span className="sr-only"> (opens in a new tab)</span>
      </a>
    );
  }
  if (href.startsWith("tel:") || href.startsWith("mailto:")) {
    return (
      <a href={href} className={classes} aria-label={ariaLabel}>
        {inner}
      </a>
    );
  }
  return (
    <Link href={href} className={classes} aria-label={ariaLabel}>
      {inner}
    </Link>
  );
}

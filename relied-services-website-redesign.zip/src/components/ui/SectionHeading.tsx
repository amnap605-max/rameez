import { cn } from "@/lib/cn";

type Props = {
  eyebrow?: string;
  title: string;
  text?: string;
  align?: "center" | "left";
  tone?: "light" | "dark";
  as?: "h1" | "h2";
  className?: string;
};

/** Standard section heading: red accent line + eyebrow + title + intro text. */
export function SectionHeading({
  eyebrow,
  title,
  text,
  align = "center",
  tone = "light",
  as: Tag = "h2",
  className,
}: Props) {
  const dark = tone === "dark";
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      {eyebrow && (
        <p
          className={cn(
            "mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em]",
            align === "center" && "justify-center",
            dark ? "text-white/80" : "text-action",
          )}
        >
          <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
          {eyebrow}
          {align === "center" && <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />}
        </p>
      )}
      <Tag
        className={cn(
          "font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]",
          dark ? "text-white" : "text-navy",
        )}
      >
        {title}
      </Tag>
      {text && (
        <p className={cn("mt-4 text-lg leading-relaxed", dark ? "text-white/80" : "text-body")}>{text}</p>
      )}
    </div>
  );
}

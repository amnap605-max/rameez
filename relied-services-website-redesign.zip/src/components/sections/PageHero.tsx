import Link from "next/link";
import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";

type Crumb = { label: string; href?: string };

/** Shared navy hero used at the top of every inner page. */
export function PageHero({
  eyebrow,
  title,
  text,
  crumbs,
  children,
}: {
  eyebrow?: string;
  title: string;
  text?: string;
  crumbs?: Crumb[];
  children?: ReactNode;
}) {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy py-14 text-white sm:py-20">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10" />
      <div aria-hidden="true" className="absolute -right-40 -top-32 -z-10 size-[520px] rounded-full bg-navy-mid/50 blur-3xl" />
      <div className="container-x">
        {crumbs && (
          <nav aria-label="Breadcrumb" className="mb-6">
            <ol className="flex flex-wrap items-center gap-1.5 text-sm text-white/75">
              <li>
                <Link href="/" className="hover:text-white">
                  Home
                </Link>
              </li>
              {crumbs.map((c) => (
                <li key={c.label} className="flex items-center gap-1.5">
                  <ChevronRight className="size-3.5 opacity-60" aria-hidden="true" />
                  {c.href ? (
                    <Link href={c.href} className="hover:text-white">
                      {c.label}
                    </Link>
                  ) : (
                    <span aria-current="page" className="font-semibold text-white">
                      {c.label}
                    </span>
                  )}
                </li>
              ))}
            </ol>
          </nav>
        )}
        {eyebrow && (
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-white/80">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            {eyebrow}
          </p>
        )}
        <h1 className="max-w-4xl font-display text-4xl font-extrabold leading-[1.08] text-white sm:text-5xl lg:text-[3.4rem]">
          {title}
        </h1>
        <div className="mt-6 h-1 w-20 rounded-full bg-action" aria-hidden="true" />
        {text && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">{text}</p>}
        {children && <div className="mt-8 flex flex-col gap-3 sm:flex-row">{children}</div>}
      </div>
    </section>
  );
}

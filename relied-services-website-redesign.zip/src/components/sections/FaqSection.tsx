import { Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { FaqAccordion } from "@/components/sections/FaqAccordion";
import { FAQS } from "@/content/faqs";
import { SITE } from "@/content/site";

export function FaqSection({
  limit,
  asPageHeading = false,
  tone = "light",
}: {
  limit?: number;
  asPageHeading?: boolean;
  tone?: "light" | "white";
}) {
  const items = limit ? FAQS.slice(0, limit) : FAQS;
  return (
    <section
      id="faqs"
      className={`${tone === "light" ? "bg-light" : "bg-white"} py-20 sm:py-24`}
      aria-labelledby="faq-heading"
    >
      <div className="container-x">
        <Reveal>
          <div id="faq-heading">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              text="Quick answers about our plumbing services, scheduling, and how to reach us."
              as={asPageHeading ? "h1" : "h2"}
            />
          </div>
        </Reveal>
        <Reveal className="mx-auto mt-12 max-w-3xl">
          <FaqAccordion items={items} />
          <div className="mt-10 flex flex-col items-center gap-4 rounded-2xl bg-navy p-7 text-center sm:flex-row sm:justify-between sm:text-left dark-surface">
            <p className="font-display text-lg font-bold text-white">Still have a question? We are happy to help.</p>
            <Button href={SITE.phoneHref} icon={<Phone className="size-5" aria-hidden="true" />}>
              Call {SITE.phoneDisplay}
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

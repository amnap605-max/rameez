import Image from "next/image";
import { CalendarCheck, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SITE } from "@/content/site";

export function BookingCta({
  heading = "Let’s Get Your Plumbing Back on Track",
  text = "Whether it is a leak, a clogged drain, or a water heater that is not keeping up, tell us what is going on. Book your service online or call us directly and we will help you get started.",
}: {
  heading?: string;
  text?: string;
}) {
  return (
    <section id="book" className="dark-surface relative isolate overflow-hidden bg-navy-deep py-20 text-white sm:py-24">
      <Image
        src="/images/cta-bg.jpg"
        alt=""
        fill
        sizes="100vw"
        className="-z-20 object-cover opacity-25"
        aria-hidden="true"
      />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-r from-navy-deep via-navy-deep/90 to-navy/70" />
      <div className="container-x">
        <Reveal className="mx-auto max-w-3xl text-center">
          <p className="mb-4 flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-white/80">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            Book Online or Call
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
          </p>
          <h2 className="font-display text-3xl font-extrabold text-white sm:text-4xl lg:text-5xl">{heading}</h2>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-white/80">{text}</p>
          <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
            <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
              Book a Service
            </Button>
            <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
              Call {SITE.phoneDisplay}
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

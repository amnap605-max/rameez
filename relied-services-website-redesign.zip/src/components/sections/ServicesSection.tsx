import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ServiceCard } from "@/components/sections/ServiceCard";
import { SERVICES } from "@/content/services";

export function ServicesSection({ asPageHeading = false }: { asPageHeading?: boolean }) {
  return (
    <section id="services" className="bg-light py-20 sm:py-24" aria-labelledby="services-heading">
      <div className="container-x">
        <Reveal>
          <div id="services-heading">
            <SectionHeading
              eyebrow="Our Services"
              title="Complete Plumbing Services for Your Home & Business"
              text="From routine maintenance to urgent repairs, we help keep your plumbing systems operating properly."
              as={asPageHeading ? "h1" : "h2"}
            />
          </div>
        </Reveal>
        <div className="mt-14 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => (
            <Reveal key={service.slug} delay={(i % 3) * 90} className="h-full">
              <ServiceCard service={service} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

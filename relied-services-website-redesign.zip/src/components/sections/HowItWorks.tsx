import { CalendarCheck, ClipboardList, Phone } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";

const STEPS = [
  {
    icon: Phone,
    title: "Call or Book Online",
    text: "Call 470-430-3022 or use our online booking page — whichever is easiest.",
  },
  {
    icon: ClipboardList,
    title: "Tell Us What’s Going On",
    text: "Describe the problem or the service you need so we understand what is involved.",
  },
  {
    icon: CalendarCheck,
    title: "Get Your Service Scheduled",
    text: "We will work with you to schedule your plumbing service.",
  },
];

export function HowItWorks() {
  return (
    <section className="bg-white py-20 sm:py-24" aria-labelledby="how-heading">
      <div className="container-x">
        <Reveal>
          <div id="how-heading">
            <SectionHeading eyebrow="Getting Started" title="Getting Help Is Simple" />
          </div>
        </Reveal>
        <ol className="mt-12 grid gap-6 md:grid-cols-3">
          {STEPS.map(({ icon: Icon, title, text }, i) => (
            <li key={title}>
              <Reveal delay={i * 90} className="h-full">
                <div className="relative h-full rounded-2xl bg-light p-7 ring-1 ring-slate-200/70">
                  <span className="absolute right-6 top-5 font-display text-5xl font-extrabold text-navy/10" aria-hidden="true">
                    {i + 1}
                  </span>
                  <span className="grid size-14 place-items-center rounded-xl bg-navy text-action">
                    <Icon className="size-7" aria-hidden="true" />
                  </span>
                  <h3 className="mt-5 text-xl font-bold">
                    <span className="sr-only">Step {i + 1}: </span>
                    {title}
                  </h3>
                  <p className="mt-2.5 leading-relaxed">{text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

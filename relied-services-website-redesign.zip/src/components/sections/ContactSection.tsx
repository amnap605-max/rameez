import { CalendarCheck, Clock, Mail, MapPin, Phone } from "lucide-react";
import { ContactForm } from "@/components/forms/ContactForm";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SITE } from "@/content/site";

const row = "flex items-start gap-4";
const iconWrap = "grid size-12 shrink-0 place-items-center rounded-xl bg-navy text-action";

export function ContactSection({ idPrefix = "home" }: { idPrefix?: string }) {
  return (
    <section id="contact" className="bg-light py-20 sm:py-24" aria-labelledby={`${idPrefix}-contact-heading`}>
      <div className="container-x grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        <Reveal>
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            Contact Us
          </p>
          <h2
            id={`${idPrefix}-contact-heading`}
            className="font-display text-3xl font-extrabold text-navy sm:text-4xl lg:text-[2.6rem]"
          >
            Talk to a Real Plumber
          </h2>
          <p className="mt-5 text-lg leading-relaxed">
            Have a plumbing problem or a project in mind? Send us a message, call, or book online — whichever is
            easiest for you.
          </p>

          <ul className="mt-8 space-y-6">
            <li className={row}>
              <span className={iconWrap}>
                <Phone className="size-6" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-bold uppercase tracking-wider text-body">Call us</p>
                <a href={SITE.phoneHref} className="font-display text-2xl font-extrabold text-navy hover:text-navy-mid">
                  {SITE.phoneDisplay}
                </a>
              </div>
            </li>
            <li className={row}>
              <span className={iconWrap}>
                <Mail className="size-6" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-bold uppercase tracking-wider text-body">Email</p>
                <a href={`mailto:${SITE.email}`} className="break-all text-lg font-bold text-navy hover:text-navy-mid">
                  {SITE.email}
                </a>
              </div>
            </li>
            <li className={row}>
              <span className={iconWrap}>
                <MapPin className="size-6" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-bold uppercase tracking-wider text-body">Location</p>
                <p className="text-lg font-bold text-navy">{SITE.locationLong}</p>
                <p className="text-sm">Serving the Greater Atlanta area</p>
              </div>
            </li>
            <li className={row}>
              <span className={iconWrap}>
                <Clock className="size-6" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-bold uppercase tracking-wider text-body">Business hours</p>
                {SITE.hours.map((h) => (
                  <p key={h.days} className="text-[0.97rem]">
                    <span className="font-bold text-navy">{h.days}:</span> {h.time}
                  </p>
                ))}
                <p className="mt-1 text-sm">For plumbing emergencies, call {SITE.phoneDisplay}.</p>
              </div>
            </li>
          </ul>

          <div className="mt-9 rounded-2xl bg-navy p-6 dark-surface">
            <p className="font-display text-lg font-bold text-white">Prefer to schedule online?</p>
            <p className="mt-1.5 text-sm text-white/80">Choose your service and request a time on our booking page.</p>
            <div className="mt-4">
              <Button href={SITE.bookingUrl} icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
                Book a Service
              </Button>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <ContactForm idPrefix={idPrefix} />
        </Reveal>
      </div>
    </section>
  );
}

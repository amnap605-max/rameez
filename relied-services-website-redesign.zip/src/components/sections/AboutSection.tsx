import Image from "next/image";
import { Building2, MapPin, Wrench } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SITE } from "@/content/site";

// Wording is adapted from the About text on the current reliedservices.com.
// ⚠ OWNER: "licensed and insured" and "over five years of experience" come from the
// current website — please confirm they are still accurate before launch.
const PARAGRAPHS = [
  "Relied Services was founded with a vision to provide top-quality plumbing and water damage restoration services. With our owner’s over five years of experience, we have grown into a plumbing company known for its licensed and insured expertise, backed by specialized water restoration and plumbing licenses.",
  "Located in Mableton, GA, we serve both residential and commercial clients throughout the Greater Atlanta area. We aim to be more than a service provider — we want to be a reliable partner in making sure your home or business functions smoothly.",
  "At Relied Services, we strive to exceed expectations with every project, offering personalized solutions tailored to your specific needs. Whether it’s a routine repair or an emergency, you can count on us for dependable plumbing solutions.",
];

const HIGHLIGHTS = [
  { icon: Wrench, label: "Plumbing & water damage restoration" },
  { icon: Building2, label: "Residential & commercial clients" },
  { icon: MapPin, label: "Based in Mableton, GA" },
];

export function AboutSection({ full = false }: { full?: boolean }) {
  const paragraphs = full ? PARAGRAPHS : PARAGRAPHS.slice(0, 2);
  return (
    <section id="about" className="bg-light py-20 sm:py-24" aria-labelledby="about-heading">
      <div className="container-x grid items-center gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
        <Reveal>
          <div className="relative mx-auto max-w-md pb-6 pl-6 lg:max-w-none">
            <div aria-hidden="true" className="absolute bottom-0 left-0 h-[calc(100%-2.5rem)] w-[88%] rounded-3xl bg-navy" />
            <div aria-hidden="true" className="absolute -top-0 right-0 h-24 w-24 rounded-2xl border-2 border-action/80" />
            <div className="relative aspect-[2/3] overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-slate-200">
              <Image
                src="/images/about-plumber.jpg"
                alt="Relied Services plumber in a company cap and navy uniform polo, seated on a white stool and smiling"
                fill
                sizes="(min-width: 1024px) 40vw, (min-width: 640px) 420px, 90vw"
                className="object-cover object-top"
              />
            </div>
            <div className="absolute -bottom-0 left-0 flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-xl">
              <span className="grid size-10 place-items-center rounded-full bg-navy text-action">
                <MapPin className="size-5" aria-hidden="true" />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-base font-extrabold text-navy">{SITE.locationShort}</span>
                <span className="block text-xs font-semibold text-body">Serving Greater Atlanta</span>
              </span>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            About Relied Services
          </p>
          <h2 id="about-heading" className="font-display text-3xl font-extrabold text-navy sm:text-4xl lg:text-[2.6rem]">
            Local Plumbing Expertise You Can Rely On
          </h2>
          <div className="mt-6 space-y-4 text-lg leading-relaxed">
            {paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
          <ul className="mt-7 grid gap-3 sm:grid-cols-3">
            {HIGHLIGHTS.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200/70">
                <Icon className="mt-0.5 size-5 shrink-0 text-action" aria-hidden="true" />
                <span className="text-sm font-bold leading-snug text-navy">{label}</span>
              </li>
            ))}
          </ul>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href="/contact" variant="navy" size="lg">
              Contact Our Team
            </Button>
            {!full && (
              <Button href="/about" variant="outlineNavy" size="lg">
                More About Us
              </Button>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

import { CalendarCheck, Hammer, HeartHandshake, House, Phone, Wrench, Zap } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { SITE } from "@/content/site";

const REASONS = [
  {
    icon: Wrench,
    title: "Skilled Plumbing Solutions",
    text: "Installations, repairs, and maintenance handled with precision and care.",
  },
  {
    icon: House,
    title: "Residential & Commercial Service",
    text: "Plumbing help for homeowners and business owners across the Greater Atlanta area.",
  },
  {
    icon: HeartHandshake,
    title: "Customer-Focused Communication",
    text: "Customer care is at the heart of what we do, from your first call to the finished job.",
  },
  {
    icon: Hammer,
    title: "Repairs, Installation & Maintenance",
    text: "From a leaking pipe to a new water heater, one team for the plumbing work you need.",
  },
  {
    icon: Zap,
    title: "Responsive Service for Plumbing Problems",
    text: "Plumbing problems rarely wait. Call or book online and we will help you get started.",
  },
];

export function WhyChooseUs() {
  return (
    <section
      id="why-us"
      className="dark-surface relative isolate overflow-hidden bg-navy py-20 sm:py-24"
      aria-labelledby="why-heading"
    >
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10 opacity-60" />
      <div className="container-x">
        <Reveal>
          <div id="why-heading">
            <SectionHeading
              tone="dark"
              eyebrow="Why Relied Services"
              title="Why Choose Relied Services"
              text="Dependable plumbing, clear communication, and a team that treats your property with care."
            />
          </div>
        </Reveal>

        <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-6">
          {REASONS.map(({ icon: Icon, title, text }, i) => (
            <li key={title} className={i < 3 ? "lg:col-span-2" : "lg:col-span-3"}>
              <Reveal delay={(i % 3) * 90} className="h-full">
                <div className="group h-full rounded-2xl bg-white p-7 shadow-card transition duration-300 hover:-translate-y-1.5 hover:shadow-card-hover">
                  <span className="grid size-14 place-items-center rounded-xl bg-navy text-action transition-colors duration-300 group-hover:bg-action group-hover:text-white">
                    <Icon className="size-7" aria-hidden="true" />
                  </span>
                  <h3 className="mt-5 text-xl font-bold !text-navy">{title}</h3>
                  <p className="mt-2.5 leading-relaxed text-body">{text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>

        <Reveal className="mt-12 flex flex-col justify-center gap-3 sm:flex-row">
          <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
            Book a Service
          </Button>
          <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
            Call {SITE.phoneDisplay}
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

import { ArrowRight, CalendarCheck } from "lucide-react";
import { BeforeAfterGallery } from "@/components/gallery/BeforeAfterGallery";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PROJECTS } from "@/content/projects";
import { SITE } from "@/content/site";

/** Booking prompt used under the gallery. */
export function ProjectsCta({ showAllLink = false }: { showAllLink?: boolean }) {
  return (
    <div className="dark-surface relative mt-14 overflow-hidden rounded-3xl bg-navy px-6 py-10 text-center text-white shadow-card sm:px-12 sm:py-12">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 opacity-70" />
      <div className="relative">
        <p className="font-display text-2xl font-extrabold text-white sm:text-3xl">
          Need a Plumbing Repair? <span className="text-white/85">Book Your Service.</span>
        </p>
        <p className="mx-auto mt-3 max-w-xl text-white/80">
          Tell us what is going on and we will help you get service scheduled.
        </p>
        <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
          <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
            Book Your Service
          </Button>
          {showAllLink && (
            <Button
              href="/projects"
              variant="outlineLight"
              size="lg"
              iconRight={<ArrowRight className="size-5" aria-hidden="true" />}
            >
              View All Projects
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export function ProjectsSection({ limit = 3 }: { limit?: number }) {
  return (
    <section id="projects" className="bg-white py-20 sm:py-24" aria-labelledby="projects-heading">
      <div className="container-x">
        <Reveal>
          <div id="projects-heading">
            <SectionHeading
              eyebrow="Our Work"
              title="Real Plumbing Transformations"
              text="See the difference professional plumbing work can make."
            />
          </div>
          <p className="mx-auto mt-5 max-w-2xl text-center text-sm font-medium text-slate-600">
            The comparisons below are sample placeholders that show how our before-and-after gallery works. Real
            Relied Services project photos will appear here.
          </p>
        </Reveal>
        <Reveal className="mt-12">
          <BeforeAfterGallery items={PROJECTS.slice(0, limit)} />
        </Reveal>
        <Reveal>
          <ProjectsCta showAllLink />
        </Reveal>
      </div>
    </section>
  );
}

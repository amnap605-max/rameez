"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import type { Faq } from "@/content/faqs";
import { cn } from "@/lib/cn";

/**
 * Accessible accordion: each question is a real <button> with aria-expanded /
 * aria-controls, the answer is a labelled region, and closed answers are
 * removed from the tab order with `inert`.
 */
export function FaqAccordion({ items, idPrefix = "faq" }: { items: Faq[]; idPrefix?: string }) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="space-y-3.5">
      {items.map((item, i) => {
        const isOpen = open === i;
        const btnId = `${idPrefix}-q-${i}`;
        const panelId = `${idPrefix}-a-${i}`;
        return (
          <div
            key={item.q}
            className={cn(
              "overflow-hidden rounded-xl bg-white ring-1 transition-shadow duration-300",
              isOpen ? "shadow-card ring-navy/25" : "ring-slate-200 hover:ring-navy/30",
            )}
          >
            <h3 className="text-base">
              <button
                id={btnId}
                type="button"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex min-h-[4rem] w-full items-center justify-between gap-4 px-5 py-4 text-left font-display text-[1.05rem] font-bold text-navy sm:px-6 sm:text-lg"
              >
                <span className="flex items-center gap-3">
                  <span
                    className={cn("h-8 w-1 shrink-0 rounded-full transition-colors", isOpen ? "bg-action" : "bg-slate-300")}
                    aria-hidden="true"
                  />
                  {item.q}
                </span>
                <ChevronDown
                  className={cn("size-5 shrink-0 text-action transition-transform duration-300", isOpen && "rotate-180")}
                  aria-hidden="true"
                />
              </button>
            </h3>
            <div
              id={panelId}
              role="region"
              aria-labelledby={btnId}
              inert={!isOpen}
              className={cn(
                "grid transition-[grid-template-rows] duration-300 ease-out",
                isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
              )}
            >
              <div className="overflow-hidden">
                <p className="px-5 pb-6 pl-[2.75rem] pr-5 text-[1.02rem] leading-relaxed text-body sm:pl-[3.25rem] sm:pr-8">
                  {item.a}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CalendarCheck,
  Check,
  Clock,
  ExternalLink,
  House,
  Mail,
  MapPin,
  Navigation,
  PenLine,
  Phone,
  Quote,
  Siren,
  Wrench,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { FaqAccordion } from "@/components/sections/FaqAccordion";
import { BeforeAfterGallery } from "@/components/gallery/BeforeAfterGallery";
import { ContactForm } from "@/components/forms/ContactForm";
import { GoogleReviewButtons } from "@/components/sections/ReviewsSection";
import { ServiceIcon } from "@/components/ui/ServiceIcon";
import { FAQS } from "@/content/faqs";
import { PROJECTS } from "@/content/projects";
import { REVIEWS } from "@/content/reviews";
import { SERVICES } from "@/content/services";
import { SITE } from "@/content/site";

/* ============================================================================
 *  HOMEPAGE CONCEPT B — same brand palette, same verified content, different
 *  layout language: full-bleed hero photo, editorial service list, dark
 *  gallery band, navy review cards, two-panel booking CTA.
 * ==========================================================================*/

const TRUST = [
  { icon: House, label: "Residential & Commercial Plumbing" },
  { icon: Siren, label: "Emergency Plumbing Assistance" },
  { icon: Wrench, label: "Professional Repairs & Installations" },
];

export function BHero() {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy-deep text-white">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10" />
      <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
        {/* Left: message */}
        <div className="container-x flex flex-col justify-center py-14 sm:py-20 lg:ml-auto lg:mr-0 lg:max-w-[42rem] lg:py-24 lg:pr-10">
          <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-4 py-1.5 text-sm font-semibold text-white/90">
            <MapPin className="size-4 text-action" aria-hidden="true" />
            Serving {SITE.serviceArea}
          </p>

          <h1 className="mt-6 font-display text-[2.35rem] font-extrabold leading-[1.06] text-white sm:text-5xl xl:text-[3.5rem]">
            Dependable Plumbing for Homes &amp; Businesses in Greater Atlanta
          </h1>
          <div className="mt-6 h-1 w-24 rounded-full bg-action" aria-hidden="true" />
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/80">
            From everyday plumbing repairs to urgent plumbing emergencies, Relied Services delivers dependable
            solutions for homes and businesses throughout Mableton and the Greater Atlanta area.
          </p>

          <ul className="mt-8 grid gap-3 sm:grid-cols-3">
            {TRUST.map(({ icon: Icon, label }) => (
              <li key={label} className="rounded-xl border border-white/12 bg-white/[0.04] p-4">
                <Icon className="size-6 text-action" aria-hidden="true" />
                <span className="mt-2.5 block text-sm font-bold leading-snug text-white">{label}</span>
              </li>
            ))}
          </ul>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
              Book a Service
            </Button>
            <Button href={SITE.phoneHref} variant="outlineLight" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
              Call {SITE.phoneDisplay}
            </Button>
          </div>
          <div className="mt-4">
            <Button
              href={SITE.googleProfileUrl}
              variant="ghostLight"
              size="sm"
              icon={<MapPin className="size-4 text-action" aria-hidden="true" />}
              iconRight={<ExternalLink className="size-3.5 opacity-70" aria-hidden="true" />}
              className="!px-0"
            >
              View Our Google Reviews
            </Button>
          </div>
        </div>

        {/* Right: full-bleed photo */}
        <div className="relative min-h-[22rem] w-full lg:min-h-[41rem]">
          <Image
            src="/images/hero-plumber.jpg"
            alt="Relied Services plumber in a company cap and navy uniform polo, smiling with hands on hips"
            fill
            priority
            sizes="(min-width: 1024px) 48vw, 100vw"
            className="object-cover object-[center_18%]"
          />
          <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-navy-deep/85 via-navy-deep/20 to-transparent" />
          <div aria-hidden="true" className="absolute inset-y-0 left-0 hidden w-1.5 bg-action lg:block" />

          <a
            href={SITE.phoneHref}
            className="absolute bottom-6 left-6 right-6 flex items-center gap-4 rounded-2xl bg-white px-5 py-4 text-navy shadow-2xl transition hover:-translate-y-0.5 sm:left-8 sm:right-auto sm:min-w-[19rem]"
            style={{ outlineColor: "#163A63" }}
          >
            <span className="grid size-12 shrink-0 place-items-center rounded-full bg-action text-white">
              <Phone className="size-5" aria-hidden="true" />
            </span>
            <span className="leading-tight">
              <span className="block text-xs font-semibold uppercase tracking-wider text-body">
                Talk to a plumber now
              </span>
              <span className="block font-display text-xl font-extrabold">{SITE.phoneDisplay}</span>
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}

const STRIP = [
  { icon: House, label: "Residential Plumbing" },
  { icon: Building2, label: "Commercial Plumbing" },
  { icon: Siren, label: "Emergency Repairs" },
  { icon: BadgeCheck, label: "Professional Service" },
];

export function BTrustStrip() {
  return (
    <section aria-label="What we offer" className="dark-surface bg-navy text-white">
      <ul className="container-x grid grid-cols-2 gap-y-6 py-8 lg:grid-cols-4">
        {STRIP.map(({ icon: Icon, label }) => (
          <li key={label} className="flex items-center justify-center gap-3 px-2 text-center lg:text-left">
            <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-action text-white">
              <Icon className="size-5" aria-hidden="true" />
            </span>
            <span className="font-display text-sm font-bold leading-tight sm:text-[0.95rem]">{label}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function BServices() {
  return (
    <section className="bg-white py-20 sm:py-24" aria-labelledby="b-services-heading">
      <div className="container-x">
        <Reveal>
          <div className="max-w-3xl">
            <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
              Our Services
            </p>
            <h2 id="b-services-heading" className="font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]">
              Complete Plumbing Services for Your Home &amp; Business
            </h2>
            <p className="mt-4 text-lg">
              From routine maintenance to urgent repairs, we help keep your plumbing systems operating properly.
            </p>
          </div>
        </Reveal>

        <ul className="mt-12 divide-y divide-slate-200 border-y border-slate-200">
          {SERVICES.map((service, i) => (
            <li key={service.slug}>
              <Reveal delay={(i % 2) * 70}>
                <Link
                  href={`/services/${service.slug}`}
                  className="group flex flex-col gap-5 py-6 transition-colors hover:bg-light/70 focus-visible:bg-light sm:flex-row sm:items-center sm:gap-7 sm:px-4"
                >
                  <span className="relative aspect-[4/3] w-full shrink-0 overflow-hidden rounded-xl bg-navy-mid sm:aspect-square sm:w-36">
                    <Image
                      src={service.image}
                      alt={service.imageAlt}
                      fill
                      sizes="(min-width: 640px) 144px, 100vw"
                      className="object-cover transition duration-700 group-hover:scale-105"
                    />
                    <span className="absolute left-3 top-3 grid size-9 place-items-center rounded-lg bg-navy/90 text-action">
                      <ServiceIcon name={service.icon} className="size-[1.05rem]" />
                    </span>
                  </span>
                  <span className="flex-1">
                    <span className="flex items-baseline gap-3">
                      <span className="font-display text-sm font-extrabold text-action" aria-hidden="true">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="font-display text-xl font-bold text-navy sm:text-2xl">{service.title}</span>
                    </span>
                    <span className="mt-2 block max-w-2xl leading-relaxed text-body">{service.summary}</span>
                  </span>
                  <span className="inline-flex items-center gap-2 self-start font-bold text-action sm:self-center">
                    Learn More
                    <span className="sr-only"> about {service.title}</span>
                    <ArrowRight
                      className="size-4 transition-transform duration-300 group-hover:translate-x-1.5"
                      aria-hidden="true"
                    />
                  </span>
                </Link>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function BGallery() {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy-deep py-20 sm:py-24" aria-labelledby="b-gallery-heading">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10 opacity-60" />
      <div aria-hidden="true" className="absolute left-0 right-0 top-0 h-1 bg-gradient-to-r from-navy-light via-action to-navy-light" />
      <div className="container-x">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-3 flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-white/80">
              <span className="h-[3px] w-8 rounded-full bg-navy-light" aria-hidden="true" />
              Our Work
              <span className="h-[3px] w-8 rounded-full bg-navy-light" aria-hidden="true" />
            </p>
            <h2 id="b-gallery-heading" className="font-display text-3xl font-extrabold text-white sm:text-4xl lg:text-[2.6rem]">
              Real Plumbing Transformations
            </h2>
            <p className="mt-4 text-lg text-white/80">See the difference professional plumbing work can make.</p>
            <p className="mx-auto mt-5 max-w-2xl text-sm font-medium text-white/65">
              These comparisons are illustrative examples that show how the gallery works. Real Relied Services project
              photos will appear here once provided.
            </p>
          </div>
        </Reveal>
        <Reveal className="mt-12">
          <BeforeAfterGallery items={PROJECTS.slice(0, 3)} />
        </Reveal>
        <Reveal className="mt-12 flex flex-col justify-center gap-3 sm:flex-row">
          <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
            Need a Repair? Book Your Service
          </Button>
          <Button href="/projects" variant="outlineLight" size="lg" iconRight={<ArrowRight className="size-5" aria-hidden="true" />}>
            View All Projects
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

export function BAbout() {
  return (
    <section className="bg-light py-20 sm:py-24" aria-labelledby="b-about-heading">
      <div className="container-x grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-20">
        <Reveal>
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            About Relied Services
          </p>
          <h2 id="b-about-heading" className="font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]">
            Local Plumbing Expertise You Can Rely On
          </h2>
          <div className="mt-6 space-y-4 text-lg leading-relaxed">
            <p>
              Relied Services was founded with a vision to provide top-quality plumbing and water damage restoration
              services. With our owner’s over five years of experience, we have grown into a plumbing company known for
              its licensed and insured expertise, backed by specialized water restoration and plumbing licenses.
            </p>
            <p>
              Located in Mableton, GA, we serve both residential and commercial clients throughout the Greater Atlanta
              area — aiming to be a reliable partner in making sure your home or business functions smoothly.
            </p>
          </div>
          <blockquote className="mt-8 rounded-2xl border-l-4 border-action bg-white p-6 shadow-sm">
            <Quote className="size-6 fill-current text-action" aria-hidden="true" />
            <p className="mt-3 font-display text-lg font-bold leading-snug text-navy">
              “We are REAL plumbers!”
            </p>
            <footer className="mt-1 text-sm font-semibold text-body">Relied Services</footer>
          </blockquote>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href="/contact" variant="navy" size="lg">
              Contact Our Team
            </Button>
            <Button href="/about" variant="outlineNavy" size="lg">
              More About Us
            </Button>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="relative mx-auto max-w-md lg:max-w-none">
            <div aria-hidden="true" className="absolute -right-4 -top-4 h-full w-full rounded-3xl bg-navy" />
            <div aria-hidden="true" className="absolute -bottom-4 -left-4 h-28 w-28 rounded-2xl border-2 border-action/80" />
            <div className="relative aspect-[4/5] overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-slate-200">
              <Image
                src="/images/about-plumber.jpg"
                alt="Relied Services plumber in a company cap and navy uniform polo, seated on a white stool and smiling"
                fill
                sizes="(min-width: 1024px) 40vw, 90vw"
                className="object-cover object-top"
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

const REASONS = [
  { icon: Wrench, title: "Skilled Plumbing Solutions", text: "Installations, repairs, and maintenance handled with precision and care." },
  { icon: House, title: "Residential & Commercial Service", text: "Plumbing help for homeowners and business owners across the Greater Atlanta area." },
  { icon: Quote, title: "Customer-Focused Communication", text: "Customer care is at the heart of what we do, from your first call to the finished job." },
  { icon: BadgeCheck, title: "Repairs, Installation & Maintenance", text: "From a leaking pipe to a new water heater, one team for the plumbing work you need." },
  { icon: Siren, title: "Responsive Service for Plumbing Problems", text: "Plumbing problems rarely wait. Call or book online and we will help you get started." },
];

export function BWhyUs() {
  return (
    <section className="bg-white py-20 sm:py-24" aria-labelledby="b-why-heading">
      <div className="container-x">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-3 flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
              Why Relied Services
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            </p>
            <h2 id="b-why-heading" className="font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]">
              Why Choose Relied Services
            </h2>
            <p className="mt-4 text-lg">
              Dependable plumbing, clear communication, and a team that treats your property with care.
            </p>
          </div>
        </Reveal>
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {REASONS.map(({ icon: Icon, title, text }, i) => (
            <li key={title} className={i === 3 ? "lg:col-start-1" : ""}>
              <Reveal delay={(i % 3) * 80} className="h-full">
                <div className="flex h-full gap-4 rounded-2xl bg-navy-light/10 p-6 ring-1 ring-navy-light/30 transition duration-300 hover:-translate-y-1 hover:bg-navy-light/15 hover:ring-navy-light/50 hover:shadow-card">
                  <span className="mt-1 grid size-11 shrink-0 place-items-center rounded-lg bg-navy-light text-action">
                    <Icon className="size-[1.35rem]" aria-hidden="true" />
                  </span>
                  <span>
                    <span className="block font-display text-lg font-bold text-navy">{title}</span>
                    <span className="mt-1.5 block leading-relaxed text-body">{text}</span>
                  </span>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function BReviews() {
  return (
    <section className="bg-light py-20 sm:py-24" aria-labelledby="b-reviews-heading">
      <div className="container-x">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-3 flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
              Customer Reviews
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            </p>
            <h2 id="b-reviews-heading" className="font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]">
              What Our Customers Say
            </h2>
            <p className="mt-4 text-lg">Feedback from customers we have served in the Greater Atlanta area.</p>
          </div>
        </Reveal>
        <div className="mt-12 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((review, i) => (
            <Reveal key={review.id} delay={i * 90} className="h-full">
              <figure className="dark-surface flex h-full flex-col rounded-2xl bg-navy p-7 text-white shadow-card transition duration-300 hover:-translate-y-1">
                <Quote className="size-8 fill-current text-action" aria-hidden="true" />
                <blockquote className="mt-4 flex-1 leading-relaxed text-white/90">
                  <p>“{review.text}”</p>
                </blockquote>
                <figcaption className="mt-6 border-t border-white/15 pt-5">
                  <span className="block font-display text-lg font-extrabold">{review.name}</span>
                  <span className="mt-1 block text-sm font-semibold text-action">{review.topic}</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12">
          <GoogleReviewButtons />
          <p className="mt-5 text-center text-sm text-slate-600">
            Testimonials shown are reproduced from our website. Read and share more feedback on our Google Business
            Profile.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

export function BBooking() {
  return (
    <section className="bg-white py-16 sm:py-20" aria-labelledby="b-booking-heading">
      <div className="container-x">
        <Reveal>
          <div className="grid overflow-hidden rounded-3xl shadow-card lg:grid-cols-[1.15fr_0.85fr]">
            <div className="dark-surface relative isolate overflow-hidden bg-gradient-to-br from-navy via-navy to-navy-light p-8 sm:p-12">
              <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10 opacity-70" />
              <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-white/90">
                <span className="h-[3px] w-8 rounded-full bg-navy-light" aria-hidden="true" />
                Book Online or Call
              </p>
              <h2 id="b-booking-heading" className="font-display text-3xl font-extrabold text-white sm:text-4xl">
                Let’s Get Your Plumbing Back on Track
              </h2>
              <p className="mt-5 max-w-xl text-lg leading-relaxed text-white/80">
                Whether it is a leak, a clogged drain, or a water heater that is not keeping up, tell us what is going
                on and we will help you get started.
              </p>
              <ul className="mt-7 flex flex-wrap gap-x-7 gap-y-3 text-sm font-semibold text-white/85">
                <li className="flex items-center gap-2">
                  <Clock className="size-4 text-action" aria-hidden="true" />
                  {SITE.hours.map((h) => `${h.days} ${h.time}`).join(" · ")}
                </li>
              </ul>
            </div>
            <div className="flex flex-col justify-center gap-3 bg-action p-8 sm:p-12">
              <p className="font-display text-xl font-extrabold text-white">Ready when you are.</p>
              <p className="text-white/90">
                Book online in a few clicks, or call {SITE.phoneDisplay} and speak with us directly.
              </p>
              <div className="mt-4 grid gap-3">
                <Button href={SITE.bookingUrl} variant="light" size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
                  Book a Service
                </Button>
                <Button
                  href={SITE.phoneHref}
                  size="lg"
                  icon={<Phone className="size-5" aria-hidden="true" />}
                  className="bg-navy-deep shadow-none hover:bg-black/40"
                >
                  Call {SITE.phoneDisplay}
                </Button>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function BFaq() {
  return (
    <section className="bg-white py-20 sm:py-24" aria-labelledby="b-faq-heading">
      <div className="container-x grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <Reveal>
          <div className="lg:sticky lg:top-28">
            <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
              FAQs
            </p>
            <h2 id="b-faq-heading" className="font-display text-3xl font-extrabold sm:text-4xl">
              Frequently Asked Questions
            </h2>
            <p className="mt-4 text-lg">Quick answers about our services, scheduling, and how to reach us.</p>
            <div className="mt-8 rounded-2xl bg-light p-6 ring-1 ring-slate-200">
              <p className="font-display text-lg font-bold text-navy">Still have a question?</p>
              <p className="mt-1.5 text-[0.95rem]">We are happy to help.</p>
              <div className="mt-4">
                <Button href={SITE.phoneHref} icon={<Phone className="size-5" aria-hidden="true" />}>
                  Call {SITE.phoneDisplay}
                </Button>
              </div>
            </div>
          </div>
        </Reveal>
        <Reveal delay={100}>
          <FaqAccordion items={FAQS.slice(0, 5)} idPrefix="b-faq" />
          <Link
            href="/faqs"
            className="mt-6 inline-flex items-center gap-2 font-bold text-action hover:underline underline-offset-4"
          >
            See all FAQs
            <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

export function BServiceArea() {
  const { lat, lng, zoom } = SITE.map;
  return (
    <section className="bg-light py-20 sm:py-24" aria-labelledby="b-area-heading">
      <div className="container-x grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <div className="relative">
            <div aria-hidden="true" className="absolute -left-3 -top-3 h-full w-full rounded-3xl border-2 border-action/70" />
            <div className="relative overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-slate-200">
              <iframe
                title="Google Map showing the Relied Services business location in Mableton, Georgia"
                src={`https://maps.google.com/maps?q=${lat},${lng}&z=${zoom}&hl=en&output=embed`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="block aspect-[4/3] w-full border-0 sm:aspect-[16/11]"
                allowFullScreen
              />
            </div>
          </div>
        </Reveal>
        <Reveal delay={100}>
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            Service Area
          </p>
          <h2 id="b-area-heading" className="font-display text-3xl font-extrabold sm:text-4xl lg:text-[2.6rem]">
            Serving Mableton &amp; the Greater Atlanta Area
          </h2>
          <p className="mt-5 text-lg leading-relaxed">
            Relied Services is based in {SITE.locationLong} and serves residential and commercial clients throughout
            the Greater Atlanta area. Not sure whether we serve your location? Give us a call and we will let you know.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href={SITE.googleProfileUrl} variant="navy" size="lg" icon={<Navigation className="size-5" aria-hidden="true" />}>
              Find Us on Google Maps
            </Button>
            <Button href={SITE.phoneHref} variant="outlineNavy" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
              Call {SITE.phoneDisplay}
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

const CONTACT_TILES = [
  { icon: Phone, label: "Call us", value: SITE.phoneDisplay, href: SITE.phoneHref },
  { icon: Mail, label: "Email", value: SITE.email, href: `mailto:${SITE.email}` },
  { icon: MapPin, label: "Location", value: `${SITE.locationShort} · Greater Atlanta area` },
];

export function BContact() {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy py-20 sm:py-24" aria-labelledby="b-contact-heading">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10 opacity-60" />
      <div className="container-x">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-3 flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-white/80">
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
              Contact Us
              <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            </p>
            <h2 id="b-contact-heading" className="font-display text-3xl font-extrabold text-white sm:text-4xl lg:text-[2.6rem]">
              Talk to a Real Plumber
            </h2>
            <p className="mt-4 text-lg text-white/80">
              Send us a message, call, or book online — whichever is easiest for you.
            </p>
          </div>
        </Reveal>

        <ul className="mx-auto mt-10 grid max-w-4xl gap-4 sm:grid-cols-3">
          {CONTACT_TILES.map(({ icon: Icon, label, value, href }) => {
            const inner = (
              <>
                <Icon className="size-5 text-action" aria-hidden="true" />
                <span className="mt-3 block text-xs font-bold uppercase tracking-wider text-white/70">{label}</span>
                <span className="mt-1 block break-words font-display text-lg font-extrabold text-white">{value}</span>
              </>
            );
            return (
              <li key={label}>
                <Reveal delay={80}>
                  {href ? (
                    <a
                      href={href}
                      className="block h-full rounded-2xl border border-white/15 bg-white/[0.06] p-5 transition hover:border-white/40 hover:bg-white/[0.1]"
                    >
                      {inner}
                    </a>
                  ) : (
                    <div className="h-full rounded-2xl border border-white/15 bg-white/[0.06] p-5">{inner}</div>
                  )}
                </Reveal>
              </li>
            );
          })}
        </ul>

        <Reveal delay={140} className="mx-auto mt-10 max-w-3xl">
          <ContactForm idPrefix="b" />
        </Reveal>

        <Reveal className="mt-8 text-center">
          <Button
            href={SITE.bookingUrl}
            variant="outlineLight"
            size="lg"
            icon={<Check className="size-5" aria-hidden="true" />}
          >
            Or book a service online
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

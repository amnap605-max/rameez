import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ServiceIcon } from "@/components/ui/ServiceIcon";
import type { Service } from "@/content/services";

/** Reusable service card (image, icon badge, title, summary, "Learn More"). */
export function ServiceCard({ service }: { service: Service }) {
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-slate-200/60 transition duration-300 ease-out hover:-translate-y-1.5 hover:shadow-card-hover">
      <div className="relative aspect-[16/10] overflow-hidden bg-navy-mid">
        <Image
          src={service.image}
          alt={service.imageAlt}
          fill
          sizes="(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw"
          style={{ objectPosition: service.imagePosition }}
          className="object-cover transition duration-700 ease-out group-hover:scale-[1.06]"
        />
        <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-navy/45 to-transparent" />
        <span className="absolute -bottom-0 left-6 grid size-12 translate-y-1/2 place-items-center rounded-xl bg-navy text-action shadow-lg ring-4 ring-white">
          <ServiceIcon name={service.icon} className="size-6" />
        </span>
      </div>
      <div className="flex flex-1 flex-col px-6 pb-6 pt-10">
        <h3 className="text-xl font-bold">{service.title}</h3>
        <p className="mt-2.5 flex-1 text-[0.97rem] leading-relaxed text-body">{service.summary}</p>
        <Link
          href={`/services/${service.slug}`}
          className="mt-5 inline-flex items-center gap-2 font-bold text-action after:absolute after:inset-0 after:content-['']"
        >
          Learn More
          <span className="sr-only"> about {service.title}</span>
          <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1.5" aria-hidden="true" />
        </Link>
      </div>
      <span
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 h-1 origin-left scale-x-0 bg-action transition-transform duration-500 group-hover:scale-x-100"
      />
    </article>
  );
}

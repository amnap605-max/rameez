import Image from "next/image";
import { CalendarCheck, Check, ExternalLink, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { SITE } from "@/content/site";

const TRUST_POINTS = [
  "Residential & Commercial Plumbing",
  "Emergency Plumbing Assistance",
  "Professional Repairs & Installations",
];

export function Hero() {
  return (
    <section className="dark-surface relative isolate overflow-hidden bg-navy-deep text-white">
      <div aria-hidden="true" className="bg-blueprint absolute inset-0 -z-10" />
      <div
        aria-hidden="true"
        className="absolute -right-48 -top-24 -z-10 size-[640px] rounded-full bg-navy-mid/45 blur-3xl"
      />

      <div className="container-x grid items-center gap-14 py-14 sm:py-20 lg:grid-cols-[1.08fr_0.92fr] lg:gap-12 lg:py-24">
        {/* Left: message + CTAs */}
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-4 py-1.5 text-sm font-semibold text-white/90">
            <MapPin className="size-4 text-action" aria-hidden="true" />
            Plumbing in {SITE.locationShort} &amp; the Greater Atlanta Area
          </p>

          <h1 className="mt-6 font-display text-[2.4rem] font-extrabold leading-[1.06] text-white sm:text-5xl xl:text-[3.6rem]">
            Reliable Plumbing Solutions.
            <span className="mt-1 block text-white/90">When You Need Them Most.</span>
          </h1>
          <div className="mt-6 h-1 w-20 rounded-full bg-action" aria-hidden="true" />

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/80">
            From everyday plumbing repairs to urgent plumbing emergencies, Relied Services delivers dependable
            solutions for homes and businesses throughout Mableton and the Greater Atlanta area.
          </p>

          <ul className="mt-7 space-y-3">
            {TRUST_POINTS.map((point) => (
              <li key={point} className="flex items-center gap-3 font-semibold text-white">
                <span className="grid size-6 shrink-0 place-items-center rounded-full bg-action">
                  <Check className="size-3.5 text-white" strokeWidth={3} aria-hidden="true" />
                </span>
                {point}
              </li>
            ))}
          </ul>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href={SITE.bookingUrl} size="lg" icon={<CalendarCheck className="size-5" aria-hidden="true" />}>
              Book a Service
            </Button>
            <Button
              href={SITE.phoneHref}
              variant="outlineLight"
              size="lg"
              icon={<Phone className="size-5" aria-hidden="true" />}
            >
              Call {SITE.phoneDisplay}
            </Button>
          </div>
          <div className="mt-4">
            <Button
              href={SITE.googleProfileUrl}
              variant="ghostLight"
              size="sm"
              icon={<MapPin className="size-4 text-action" aria-hidden="true" />}
              iconRight={<ExternalLink className="size-3.5 opacity-70" aria-hidden="true" />}
              className="!px-0"
            >
              View Our Google Reviews
            </Button>
          </div>
        </div>

        {/* Right: layered photography */}
        <div className="relative mx-auto w-full max-w-[28rem] pb-12 pl-6 sm:pl-10 lg:max-w-none lg:pl-8">
          <div
            aria-hidden="true"
            className="absolute -right-3 top-5 h-[calc(100%-4rem)] w-[92%] rounded-[1.75rem] border-2 border-action/80 sm:-right-4"
          />
          <div className="relative aspect-[6/7] overflow-hidden rounded-[1.75rem] bg-navy shadow-2xl ring-1 ring-white/15">
            <Image
              src="/images/hero-plumber.jpg"
              alt="Relied Services plumber in a company cap and navy uniform polo, smiling with hands on hips"
              fill
              priority
              sizes="(min-width: 1024px) 40vw, (min-width: 640px) 440px, 90vw"
              className="object-cover"
            />
            <div
              aria-hidden="true"
              className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-navy-deep/70 to-transparent"
            />
          </div>

          {/* Inset: plumber at work */}
          <div className="absolute bottom-0 left-0 hidden aspect-[4/3] w-44 overflow-hidden rounded-2xl border-4 border-navy-deep shadow-xl sm:block sm:w-52">
            <Image
              src="/images/svc-residential.jpg"
              alt="Plumber tightening a water supply valve with a wrench"
              fill
              sizes="208px"
              className="object-cover"
            />
          </div>

          {/* Floating call card */}
          <a
            href={SITE.phoneHref}
            className="absolute -bottom-1 right-0 flex items-center gap-3 rounded-2xl bg-white px-4 py-3 text-navy shadow-xl transition hover:-translate-y-0.5 hover:shadow-2xl sm:right-2"
            style={{ outlineColor: "#163A63" }}
          >
            <span className="grid size-11 place-items-center rounded-full bg-action text-white">
              <Phone className="size-5" aria-hidden="true" />
            </span>
            <span className="leading-tight">
              <span className="block text-xs font-semibold uppercase tracking-wider text-body">Plumbing problem?</span>
              <span className="block font-display text-lg font-extrabold">{SITE.phoneDisplay}</span>
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}

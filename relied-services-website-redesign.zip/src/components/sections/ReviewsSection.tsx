import { ExternalLink, MapPin, PenLine, Quote } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { REVIEWS, type Review } from "@/content/reviews";
import { SITE } from "@/content/site";

export function ReviewCard({ review }: { review: Review }) {
  return (
    <figure className="flex h-full flex-col rounded-2xl bg-white p-7 shadow-card ring-1 ring-slate-200/70 transition duration-300 hover:-translate-y-1 hover:shadow-card-hover">
      <span className="grid size-11 place-items-center rounded-full bg-navy text-action">
        <Quote className="size-5 fill-current" aria-hidden="true" />
      </span>
      <blockquote className="mt-5 flex-1 text-[1.02rem] leading-relaxed text-body">
        <p>“{review.text}”</p>
      </blockquote>
      <figcaption className="mt-6 border-t border-slate-200 pt-5">
        <span className="block font-display text-lg font-extrabold text-navy">{review.name}</span>
        <span className="mt-1 block text-sm font-semibold text-action">{review.topic}</span>
      </figcaption>
    </figure>
  );
}

export function GoogleReviewButtons({ align = "center" }: { align?: "center" | "left" }) {
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${align === "center" ? "justify-center" : ""}`}>
      <Button
        href={SITE.googleProfileUrl}
        variant="navy"
        size="lg"
        icon={<MapPin className="size-5" aria-hidden="true" />}
        iconRight={<ExternalLink className="size-4 opacity-80" aria-hidden="true" />}
      >
        View Us on Google
      </Button>
      <Button
        href={SITE.googleReviewUrl}
        variant="outlineNavy"
        size="lg"
        icon={<PenLine className="size-5" aria-hidden="true" />}
        iconRight={<ExternalLink className="size-4 opacity-80" aria-hidden="true" />}
      >
        Leave a Google Review
      </Button>
    </div>
  );
}

export function ReviewsSection({ asPageHeading = false }: { asPageHeading?: boolean }) {
  return (
    <section id="reviews" className="bg-white py-20 sm:py-24" aria-labelledby="reviews-heading">
      <div className="container-x">
        <Reveal>
          <div id="reviews-heading">
            <SectionHeading
              eyebrow="Customer Reviews"
              title="What Our Customers Say"
              text="Feedback from customers we have served in the Greater Atlanta area."
              as={asPageHeading ? "h1" : "h2"}
            />
          </div>
        </Reveal>
        <div className="mt-14 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((review, i) => (
            <Reveal key={review.id} delay={i * 90} className="h-full">
              <ReviewCard review={review} />
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12">
          <GoogleReviewButtons />
          <p className="mt-5 text-center text-sm text-slate-600">
            Testimonials shown are reproduced from our website. Read and share more feedback on our Google Business
            Profile.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

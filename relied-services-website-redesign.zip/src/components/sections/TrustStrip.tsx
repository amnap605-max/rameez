import { BadgeCheck, Building2, House, Siren } from "lucide-react";

const ITEMS = [
  { icon: House, label: "Residential Plumbing" },
  { icon: Building2, label: "Commercial Plumbing" },
  { icon: Siren, label: "Emergency Repairs" },
  { icon: BadgeCheck, label: "Professional Service" },
];

export function TrustStrip() {
  return (
    <section aria-label="What we offer" className="border-b border-slate-200 bg-white">
      <ul className="container-x grid grid-cols-2 lg:grid-cols-4">
        {ITEMS.map(({ icon: Icon, label }, i) => (
          <li
            key={label}
            className={`flex items-center justify-center gap-3.5 px-3 py-6 sm:py-7 ${
              i % 2 === 1 ? "border-l border-slate-200" : ""
            } ${i >= 2 ? "border-t border-slate-200 lg:border-t-0" : ""} ${i > 0 ? "lg:border-l lg:border-slate-200" : ""}`}
          >
            <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-navy text-white">
              <Icon className="size-6 text-white" aria-hidden="true" />
            </span>
            <span className="font-display text-[0.95rem] font-bold leading-tight text-navy sm:text-base">{label}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

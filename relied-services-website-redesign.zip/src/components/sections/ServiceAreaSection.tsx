import { MapPin, Navigation, Phone } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SITE } from "@/content/site";

const { lat, lng, zoom } = SITE.map;
// Embeds the Google Business Profile pin for "Relied Services" (no API key required).
const MAP_EMBED = `https://maps.google.com/maps?q=${lat},${lng}&z=${zoom}&hl=en&output=embed`;

export function ServiceAreaSection() {
  return (
    <section id="service-area" className="bg-white py-20 sm:py-24" aria-labelledby="area-heading">
      <div className="container-x grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <p className="mb-3 flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-action">
            <span className="h-[3px] w-8 rounded-full bg-action" aria-hidden="true" />
            Service Area
          </p>
          <h2 id="area-heading" className="font-display text-3xl font-extrabold text-navy sm:text-4xl lg:text-[2.6rem]">
            Serving Mableton &amp; the Greater Atlanta Area
          </h2>
          <p className="mt-5 text-lg leading-relaxed">
            Relied Services is based in {SITE.locationLong} and serves residential and commercial clients throughout
            the Greater Atlanta area.
          </p>
          <ul className="mt-6 flex flex-wrap gap-3">
            {["Mableton, GA", "Greater Atlanta area", "Homes & businesses"].map((chip) => (
              <li
                key={chip}
                className="flex items-center gap-2 rounded-full bg-light px-4 py-2 text-sm font-bold text-navy ring-1 ring-slate-200"
              >
                <MapPin className="size-4 text-action" aria-hidden="true" />
                {chip}
              </li>
            ))}
          </ul>
          <p className="mt-6 leading-relaxed">
            Not sure whether we serve your location? Give us a call at{" "}
            <a href={SITE.phoneHref} className="font-bold text-navy underline decoration-action decoration-2 underline-offset-4">
              {SITE.phoneDisplay}
            </a>{" "}
            and we will let you know.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href={SITE.googleProfileUrl} variant="navy" size="lg" icon={<Navigation className="size-5" aria-hidden="true" />}>
              Find Us on Google Maps
            </Button>
            <Button href={SITE.phoneHref} variant="outlineNavy" size="lg" icon={<Phone className="size-5" aria-hidden="true" />}>
              Call {SITE.phoneDisplay}
            </Button>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="relative">
            <div aria-hidden="true" className="absolute -bottom-3 -right-3 h-full w-full rounded-3xl border-2 border-action/70" />
            <div className="relative overflow-hidden rounded-3xl bg-light shadow-card ring-1 ring-slate-200">
              <iframe
                title="Google Map showing the Relied Services business location in Mableton, Georgia"
                src={MAP_EMBED}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="block aspect-[4/3] w-full border-0 sm:aspect-[16/11]"
                allowFullScreen
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { AlertCircle, CalendarCheck, CheckCircle2, Loader2, Phone, Send } from "lucide-react";
import { SERVICE_OPTIONS, SITE } from "@/content/site";
import { EMPTY_INQUIRY, sanitizeInquiry, validateInquiry, type InquiryErrors, type InquiryInput } from "@/lib/inquiry";
import { cn } from "@/lib/cn";

type Status = "idle" | "submitting" | "success" | "error";

const inputClass =
  "block min-h-12 w-full rounded-lg border bg-white px-4 py-3 text-base text-navy placeholder:text-slate-500 transition focus:border-navy-mid focus:ring-4 focus:ring-navy-mid/20 focus-visible:outline-none";

function Field({
  id,
  label,
  required,
  optional,
  error,
  children,
  className,
}: {
  id: string;
  label: string;
  required?: boolean;
  optional?: boolean;
  error?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-bold text-navy">
        {label}
        {required && (
          <span className="text-action" aria-hidden="true">
            {" "}
            *
          </span>
        )}
        {optional && <span className="font-medium text-slate-600"> (optional)</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} className="mt-1.5 flex items-start gap-1.5 text-sm font-semibold text-action-dark">
          <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  );
}

export function ContactForm({ idPrefix = "contact" }: { idPrefix?: string }) {
  const [values, setValues] = useState<InquiryInput>(EMPTY_INQUIRY);
  const [errors, setErrors] = useState<InquiryErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverMessage, setServerMessage] = useState("");
  const [honeypot, setHoneypot] = useState("");
  const [minDate, setMinDate] = useState<string | undefined>(undefined);
  const startedAt = useRef<number>(0);
  const confirmRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    startedAt.current = Date.now();
    const d = new Date();
    setMinDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  }, []);

  useEffect(() => {
    if (status === "success") confirmRef.current?.focus();
  }, [status]);

  const id = (name: keyof InquiryInput) => `${idPrefix}-${name}`;
  const set = (name: keyof InquiryInput) => (value: string) => {
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: undefined }));
  };
  const aria = (name: keyof InquiryInput) => ({
    id: id(name),
    name,
    "aria-invalid": errors[name] ? true : undefined,
    "aria-describedby": errors[name] ? `${id(name)}-error` : undefined,
  });
  const border = (name: keyof InquiryInput) => (errors[name] ? "border-action" : "border-slate-300");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (status === "submitting") return;

    const clean = sanitizeInquiry(values);
    const found = validateInquiry(clean);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      const first = (Object.keys(found) as Array<keyof InquiryInput>)[0];
      document.getElementById(id(first))?.focus();
      return;
    }

    setStatus("submitting");
    setServerMessage("");
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...clean, company: honeypot, startedAt: startedAt.current }),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; errors?: InquiryErrors; error?: string };
      if (res.ok && data.ok) {
        setStatus("success");
        return;
      }
      if (res.status === 400 && data.errors) {
        setErrors(data.errors);
        setStatus("idle");
        return;
      }
      setServerMessage(
        res.status === 429
          ? "We have received several requests from this connection. Please wait a few minutes, or call us directly."
          : "Something went wrong while sending your request.",
      );
      setStatus("error");
    } catch {
      setServerMessage("We could not reach the server. Please check your connection.");
      setStatus("error");
    }
  }

  function reset() {
    setValues(EMPTY_INQUIRY);
    setErrors({});
    setStatus("idle");
    startedAt.current = Date.now();
  }

  if (status === "success") {
    return (
      <div
        ref={confirmRef}
        tabIndex={-1}
        role="status"
        aria-live="polite"
        className="rounded-2xl bg-white p-8 text-center shadow-card ring-1 ring-slate-200 focus-visible:outline-none sm:p-10"
      >
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-navy text-white">
          <CheckCircle2 className="size-9" aria-hidden="true" />
        </span>
        <h3 className="mt-6 text-2xl font-extrabold">Thank you, {values.firstName.trim()} — your request was sent.</h3>
        <p className="mx-auto mt-3 max-w-md leading-relaxed">
          We have received your message and will follow up using the phone number or email you provided. If your
          plumbing issue is urgent, please don’t wait — call us now.
        </p>
        <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
          <a
            href={SITE.phoneHref}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg bg-action px-6 font-semibold text-white transition hover:bg-action-dark"
          >
            <Phone className="size-5" aria-hidden="true" /> Call {SITE.phoneDisplay}
          </a>
          <a
            href={SITE.bookingUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg border-2 border-navy px-6 font-semibold text-navy transition hover:bg-navy hover:text-white"
          >
            <CalendarCheck className="size-5" aria-hidden="true" /> Book Online
            <span className="sr-only"> (opens in a new tab)</span>
          </a>
        </div>
        <button type="button" onClick={reset} className="mt-6 text-sm font-semibold text-navy-mid underline underline-offset-4">
          Send another request
        </button>
      </div>
    );
  }

  const errorCount = Object.values(errors).filter(Boolean).length;

  return (
    <form
      ref={formRef}
      onSubmit={onSubmit}
      noValidate
      aria-describedby={`${idPrefix}-privacy`}
      className="rounded-2xl bg-white p-6 shadow-card ring-1 ring-slate-200 sm:p-8"
    >
      <h3 className="text-2xl font-extrabold">Send Us a Message</h3>
      <p className="mt-1.5 text-[0.95rem]">
        Fields marked <span className="font-bold text-action">*</span> are required.
      </p>

      {errorCount > 0 && (
        <div role="alert" className="mt-5 flex items-start gap-2.5 rounded-lg border border-action/40 bg-red-50 p-4 text-sm font-semibold text-action-dark">
          <AlertCircle className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
          Please fix the {errorCount === 1 ? "field" : `${errorCount} fields`} highlighted below and try again.
        </div>
      )}
      {status === "error" && (
        <div role="alert" className="mt-5 rounded-lg border border-action/40 bg-red-50 p-4 text-sm font-semibold text-action-dark">
          {serverMessage} You can also call{" "}
          <a href={SITE.phoneHref} className="underline">
            {SITE.phoneDisplay}
          </a>{" "}
          or email{" "}
          <a href={`mailto:${SITE.email}`} className="underline">
            {SITE.email}
          </a>
          .
        </div>
      )}

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <Field id={id("firstName")} label="First Name" required error={errors.firstName}>
          <input
            {...aria("firstName")}
            type="text"
            autoComplete="given-name"
            value={values.firstName}
            onChange={(e) => set("firstName")(e.target.value)}
            className={cn(inputClass, border("firstName"))}
            required
            maxLength={80}
          />
        </Field>
        <Field id={id("lastName")} label="Last Name" required error={errors.lastName}>
          <input
            {...aria("lastName")}
            type="text"
            autoComplete="family-name"
            value={values.lastName}
            onChange={(e) => set("lastName")(e.target.value)}
            className={cn(inputClass, border("lastName"))}
            required
            maxLength={80}
          />
        </Field>
        <Field id={id("phone")} label="Phone Number" required error={errors.phone}>
          <input
            {...aria("phone")}
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="470-430-3022"
            value={values.phone}
            onChange={(e) => set("phone")(e.target.value)}
            className={cn(inputClass, border("phone"))}
            required
            maxLength={32}
          />
        </Field>
        <Field id={id("email")} label="Email Address" required error={errors.email}>
          <input
            {...aria("email")}
            type="email"
            autoComplete="email"
            value={values.email}
            onChange={(e) => set("email")(e.target.value)}
            className={cn(inputClass, border("email"))}
            required
            maxLength={160}
          />
        </Field>
        <Field id={id("service")} label="Service Needed" required error={errors.service}>
          <select
            {...aria("service")}
            value={values.service}
            onChange={(e) => set("service")(e.target.value)}
            className={cn(inputClass, border("service"))}
            required
          >
            <option value="">Select a service…</option>
            {SERVICE_OPTIONS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </Field>
        <Field id={id("preferredDate")} label="Preferred Date" optional error={errors.preferredDate}>
          <input
            {...aria("preferredDate")}
            type="date"
            min={minDate}
            value={values.preferredDate}
            onChange={(e) => set("preferredDate")(e.target.value)}
            className={cn(inputClass, border("preferredDate"))}
          />
        </Field>
        <Field id={id("message")} label="Message" required error={errors.message} className="sm:col-span-2">
          <textarea
            {...aria("message")}
            rows={5}
            value={values.message}
            onChange={(e) => set("message")(e.target.value)}
            placeholder="Tell us what is going on — for example, where the problem is and when it started."
            className={cn(inputClass, border("message"), "resize-y")}
            required
            maxLength={3000}
          />
        </Field>

        {/* Honeypot — hidden from people and assistive tech; bots tend to fill it in */}
        <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
          <label htmlFor={`${idPrefix}-company`}>Company (leave this field empty)</label>
          <input
            id={`${idPrefix}-company`}
            name="company"
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={honeypot}
            onChange={(e) => setHoneypot(e.target.value)}
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={status === "submitting"}
        className="mt-7 inline-flex min-h-14 w-full items-center justify-center gap-2.5 rounded-lg bg-action px-7 text-lg font-semibold text-white shadow-[0_8px_20px_-8px_rgba(217,39,46,0.7)] transition hover:bg-action-dark disabled:cursor-wait disabled:opacity-80"
      >
        {status === "submitting" ? (
          <>
            <Loader2 className="size-5 animate-spin" aria-hidden="true" /> Sending…
          </>
        ) : (
          <>
            <Send className="size-5" aria-hidden="true" /> Send Message
          </>
        )}
      </button>

      <p id={`${idPrefix}-privacy`} className="mt-4 text-xs leading-relaxed text-slate-600">
        By sending this form you agree that Relied Services may use your details to respond to your request. We do not
        sell your information — see our{" "}
        <Link href="/privacy-policy" className="font-semibold text-navy underline underline-offset-2">
          Privacy Policy
        </Link>
        . Please do not include payment card numbers or other sensitive information in your message.
      </p>
    </form>
  );
}

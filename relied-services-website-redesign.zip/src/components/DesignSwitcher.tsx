"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Eye, X } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/cn";

/**
 * CLIENT PREVIEW ONLY — floating A/B switcher.
 * Delete the <DesignSwitcher /> line in src/app/layout.tsx before launch.
 */
export function DesignSwitcher() {
  const pathname = usePathname();
  const [hidden, setHidden] = useState(false);

  if (hidden || pathname.startsWith("/admin")) return null;
  const onB = pathname.startsWith("/b");

  return (
    <div
      className="fixed bottom-4 right-4 z-30 hidden items-center gap-2 rounded-full bg-navy-deep/95 px-2.5 py-2 text-xs font-bold text-white shadow-2xl ring-1 ring-white/20 backdrop-blur sm:flex"
      role="group"
      aria-label="Homepage design preview switcher"
    >
      <span className="flex items-center gap-1.5 pl-1.5 pr-1 text-[0.68rem] font-semibold uppercase tracking-wider text-white/60">
        <Eye className="size-3.5" aria-hidden="true" />
        <span className="sr-only">Homepage concept preview:</span>
        Preview
      </span>
      {(
        [
          { label: "A", href: "/", isB: false },
          { label: "B", href: "/b", isB: true },
        ] as const
      ).map(({ label, href, isB }) => (
        <Link
          key={label}
          href={href}
          aria-current={(isB && onB) || (!isB && !onB) ? "true" : undefined}
          className={cn(
            "flex min-h-8 items-center gap-1.5 rounded-full px-3 py-1 transition-colors",
            (isB && onB) || (!isB && !onB) ? "bg-action text-white" : "text-white/80 hover:bg-white/10 hover:text-white",
          )}
        >
          Concept {label}
        </Link>
      ))}
      <button
        type="button"
        onClick={() => setHidden(true)}
        aria-label="Hide design preview switcher"
        className="grid size-7 place-items-center rounded-full text-white/60 transition-colors hover:bg-white/10 hover:text-white"
      >
        <X className="size-3.5" aria-hidden="true" />
      </button>
    </div>
  );
}

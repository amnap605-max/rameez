import { boolean, date, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

/**
 * Website inquiries submitted through the contact form.
 * Stored so no lead is ever lost, even if email delivery is not configured.
 * View them at /admin/inquiries (protected by ADMIN_ACCESS_KEY).
 */
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  firstName: varchar("first_name", { length: 80 }).notNull(),
  lastName: varchar("last_name", { length: 80 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
  email: varchar("email", { length: 160 }).notNull(),
  service: varchar("service", { length: 120 }).notNull(),
  preferredDate: date("preferred_date"),
  message: text("message").notNull(),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  // Hashed (never raw) IP address — used only for rate limiting / spam protection.
  ipHash: varchar("ip_hash", { length: 64 }),
  userAgent: varchar("user_agent", { length: 255 }),
  notified: boolean("notified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Inquiry = typeof inquiries.$inferSelect;

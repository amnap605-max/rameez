/**
 * CUSTOMER TESTIMONIALS
 * Reproduced from the "What Our Customers Say" section of the current
 * reliedservices.com. Wording and attribution are preserved exactly as
 * displayed (one obvious typographical "|" in the original, which should read
 * "I", has been corrected). No ratings, star counts or review totals are shown
 * because none are published on the current site.
 *
 * To add a review: add an object below (or, in WordPress, add a "Testimonial"
 * custom post). Only add real reviews with the customer's permission.
 */

export type Review = {
  id: string;
  name: string;
  /** What the review is about (taken from the review text itself) */
  topic: string;
  text: string;
};

export const REVIEWS: Review[] = [
  {
    id: "pasty-stewart",
    name: "Pasty Stewart",
    topic: "Water heater replacement",
    text: "Rod came out to remove a tankless water heater and install a regular tank he was very professional, very friendly and very punctual. He did an awesome job. I would recommend him for plumbing to anyone. I am extremely happy with his work and my new hot water heater. Great job.!!",
  },
  {
    id: "latonia-b",
    name: "Latonia B.",
    topic: "Hot water tank",
    text: "Our hot water tank was not maintaining the hot water temperature for the duration of our showers as it once did I immediately began asking for referrals and that's when Relied Services came highly recommended! I couldn't agree more, they were professional, knowledgeable, on time, and quality work. I would highly recommend them for your plumbing concerns.",
  },
  {
    id: "melissa-love",
    name: "Melissa Love",
    topic: "Toilet & bathroom sink",
    text: "Rod provided exceptional plumbing services for my half bath toilet and master bath sink. He arrived early, worked efficiently, and delivered reliable results. His communication throughout the process was excellent, keeping me informed every step of the way. I highly recommend Rod for any plumbing needs and he’s truly a professional you can count on! I highly recommend and let’s add exceptional customer service! 5 Stars",
  },
];

/**
 * SERVICES — one entry per service card AND per service page.
 * In WordPress: create a "Service" custom post type (title, excerpt = summary,
 * featured image, content = overview) and render with a Loop Grid / Query Loop.
 * Wording is based on the current reliedservices.com service descriptions.
 */

export type ServiceIcon = "home" | "building" | "siren" | "pipe" | "flame" | "drain";

export type Service = {
  slug: string;
  title: string;
  icon: ServiceIcon;
  /** Short card description */
  summary: string;
  image: string;
  imageAlt: string;
  imagePosition?: string;
  metaTitle: string;
  metaDescription: string;
  heroHeadline: string;
  heroSub: string;
  overview: string[];
  helpsWith: string[];
  callWhen: string[];
  reviewIds: string[];
  related: string[];
};

export const SERVICES: Service[] = [
  {
    slug: "residential-plumbing",
    title: "Residential Plumbing",
    icon: "home",
    summary: "Repairs, maintenance, and plumbing solutions for homeowners.",
    image: "/images/svc-residential.jpg",
    imageAlt: "Plumber using a wrench on the water supply valves behind a washer in a home laundry area",
    imagePosition: "center",
    metaTitle: "Residential Plumbing in Mableton, GA",
    metaDescription:
      "Residential plumbing repairs, maintenance and installations for homeowners in Mableton and the Greater Atlanta area. Call 470-430-3022 or book online with Relied Services.",
    heroHeadline: "Residential Plumbing in Mableton, GA",
    heroSub:
      "Repairs, maintenance, and plumbing solutions for homeowners in Mableton and throughout the Greater Atlanta area.",
    overview: [
      "Our residential plumbing services cover everything from routine maintenance to emergency repairs. We work to keep your home's plumbing systems operating properly so your home stays safe and comfortable.",
      "Relied Services serves homeowners in Mableton and across the Greater Atlanta area. Whether a fixture needs to be repaired or replaced, a leak needs attention, or your water heater is not keeping up, you can call or book online to get started.",
    ],
    helpsWith: [
      "Routine plumbing maintenance",
      "Plumbing repairs throughout the home",
      "Toilet, sink and other fixture repairs and replacements",
      "Water heater installation and replacement",
      "Pipe repair and leak attention",
      "Clogged drain clearing",
      "Emergency plumbing repairs",
    ],
    callWhen: [
      "A fixture is not working the way it should",
      "You notice a leak or water where it should not be",
      "Your hot water is not lasting the way it used to",
      "A sink, tub or toilet drains slowly or backs up",
    ],
    reviewIds: ["melissa-love", "latonia-b"],
    related: ["water-heater-installation", "drain-cleaning", "pipe-repair"],
  },
  {
    slug: "commercial-plumbing",
    title: "Commercial Plumbing",
    icon: "building",
    summary: "Plumbing services tailored to business and commercial properties.",
    image: "/images/svc-commercial.jpg",
    imageAlt: "Exposed commercial water supply pipes with shutoff valves mounted along a wall",
    imagePosition: "center",
    metaTitle: "Commercial Plumbing in Mableton & Greater Atlanta",
    metaDescription:
      "Commercial plumbing solutions for businesses in Mableton and the Greater Atlanta area. Repairs, installations and maintenance from Relied Services. Call 470-430-3022.",
    heroHeadline: "Commercial Plumbing in Mableton & Greater Atlanta",
    heroSub:
      "Plumbing solutions tailored to the needs of business and commercial properties.",
    overview: [
      "For businesses, we offer commercial plumbing solutions tailored to the needs of commercial properties. Our services help businesses maintain efficient and reliable plumbing systems to support their operations.",
      "Every commercial property is different. Call 470-430-3022 or send us a message to talk through what your property needs, and we will help you get service scheduled.",
    ],
    helpsWith: [
      "Plumbing repairs for business properties",
      "Plumbing installations",
      "Preventive plumbing maintenance",
      "Water heater installation and replacement",
      "Drain cleaning and clog removal",
      "Emergency plumbing assistance",
    ],
    callWhen: [
      "A leak or clog is disrupting your business",
      "Restroom or other fixtures are not working properly",
      "You need a plumbing installation for your property",
      "You want help keeping your plumbing system in good working order",
    ],
    reviewIds: [],
    related: ["emergency-plumbing", "drain-cleaning", "water-heater-installation"],
  },
  {
    slug: "emergency-plumbing",
    title: "Emergency Plumbing",
    icon: "siren",
    summary: "Assistance with urgent plumbing issues and unexpected leaks.",
    image: "/images/svc-emergency.jpg",
    imageAlt: "Plumber working beneath a kitchen sink next to an open blue toolbox",
    imagePosition: "center",
    metaTitle: "Emergency Plumbing in Mableton, GA",
    metaDescription:
      "Emergency plumbing assistance for burst pipes, clogged drains and water leaks in Mableton and the Greater Atlanta area. Call Relied Services at 470-430-3022.",
    heroHeadline: "Emergency Plumbing in Mableton, GA",
    heroSub:
      "Help with urgent plumbing issues and unexpected leaks, for homes and businesses across the Greater Atlanta area.",
    overview: [
      "Plumbing emergencies can happen at any time. Relied Services provides emergency plumbing services to address urgent issues and help prevent further damage — whether it is a burst pipe, a clogged drain, or a water leak.",
      "For an urgent problem, the fastest way to reach us is by phone. Call 470-430-3022 to describe what is happening and confirm availability.",
    ],
    helpsWith: [
      "Burst or busted pipes",
      "Water leaks",
      "Clogged drains and sewer clogs",
      "Urgent water heater problems",
      "Water damage & restoration needs",
    ],
    callWhen: [
      "A pipe has burst or water is actively leaking",
      "A drain is completely blocked or backing up",
      "Water is spreading where it should not be",
      "You are not sure how serious a plumbing problem is",
    ],
    reviewIds: [],
    related: ["pipe-repair", "drain-cleaning", "residential-plumbing"],
  },
  {
    slug: "pipe-repair",
    title: "Pipe Repair",
    icon: "pipe",
    summary: "Professional attention to damaged pipes, leaks, and related problems.",
    image: "/images/svc-pipe-repair.jpg",
    imageAlt: "Gloved hands using an orange pipe wrench on a chrome drain pipe under a bathroom sink",
    imagePosition: "center",
    metaTitle: "Pipe Repair in Mableton, GA",
    metaDescription:
      "Pipe repair for leaks, damaged pipes and related plumbing problems in Mableton and the Greater Atlanta area. Book online or call Relied Services at 470-430-3022.",
    heroHeadline: "Pipe Repair in Mableton, GA",
    heroSub:
      "Professional attention to damaged pipes, leaks, and related problems.",
    overview: [
      "Our team provides pipe repair services, detecting and fixing leaks, clogs, and other pipe-related issues to protect the integrity and function of your plumbing system.",
      "Our booking page also lists busted pipe repair, repiping services, and water meter repair, so you can request the specific help you need.",
    ],
    helpsWith: [
      "Leaking or damaged pipe repair",
      "Busted pipe repair",
      "Repiping services",
      "Water meter repair",
      "Pipe-related clogs",
    ],
    callWhen: [
      "You see dripping or visible damage on a pipe",
      "There are water stains on walls, ceilings or floors",
      "Water pressure suddenly changes",
      "You suspect a hidden leak",
    ],
    reviewIds: [],
    related: ["emergency-plumbing", "residential-plumbing", "drain-cleaning"],
  },
  {
    slug: "water-heater-installation",
    title: "Water Heater Installation",
    icon: "flame",
    summary: "Installation services to help maintain a dependable hot water supply.",
    image: "/images/svc-water-heater.jpg",
    imageAlt: "Home utility room with a white water heater tank beside shelving and a washing machine",
    imagePosition: "center",
    metaTitle: "Water Heater Installation in Mableton, GA",
    metaDescription:
      "Water heater installation and replacement for homes and businesses in Mableton and the Greater Atlanta area. Book online or call Relied Services at 470-430-3022.",
    heroHeadline: "Water Heater Installation in Mableton, GA",
    heroSub:
      "Installation services to help you maintain a dependable hot water supply.",
    overview: [
      "We offer professional water heater installation services so you have access to hot water when you need it. Our team handles the installation process efficiently and with care.",
      "Customers have used Relied Services for water heater replacement, including removing a tankless unit and installing a standard tank water heater. Online booking is available for water heater replacement.",
    ],
    helpsWith: [
      "Water heater installation",
      "Water heater replacement, including removing an existing unit",
      "Help when hot water is not lasting as long as it once did",
      "Residential and commercial water heaters",
    ],
    callWhen: [
      "You are running out of hot water faster than you used to",
      "You have no hot water",
      "Your water heater is leaking or failing",
      "You want to replace your current unit",
    ],
    reviewIds: ["pasty-stewart", "latonia-b"],
    related: ["residential-plumbing", "commercial-plumbing", "emergency-plumbing"],
  },
  {
    slug: "drain-cleaning",
    title: "Drain Cleaning",
    icon: "drain",
    summary: "Help clearing clogged drains and restoring proper drainage.",
    image: "/images/svc-drain-cleaning.jpg",
    imageAlt: "Plumber tightening a chrome P-trap beneath a sink with an orange wrench",
    imagePosition: "center",
    metaTitle: "Drain Cleaning in Mableton, GA",
    metaDescription:
      "Drain cleaning and clog removal for homes and businesses in Mableton and the Greater Atlanta area. Call Relied Services at 470-430-3022 or book online.",
    heroHeadline: "Drain Cleaning in Mableton, GA",
    heroSub:
      "Help clearing clogged drains and restoring proper drainage.",
    overview: [
      "Keep your drains clear with our drain cleaning services. We remove clogs, buildup, and debris from drains to help prevent blockages and keep your plumbing system running smoothly.",
      "If the problem is a deeper blockage, our booking page also lists sewer clog service.",
    ],
    helpsWith: [
      "Clogged drain clearing",
      "Removal of buildup and debris",
      "Sewer clogs",
      "Help with slow or recurring drain problems",
    ],
    callWhen: [
      "A sink, shower or tub drains slowly",
      "Water is standing in a drain",
      "Multiple drains are slow or backing up",
      "Drains are gurgling or giving off odors",
    ],
    reviewIds: [],
    related: ["emergency-plumbing", "pipe-repair", "residential-plumbing"],
  },
];

export const getService = (slug: string) => SERVICES.find((s) => s.slug === slug);

import { SITE } from "./site";

/**
 * FREQUENTLY ASKED QUESTIONS
 * Answers are based only on information published by the business (current
 * website + its online booking page). Edit freely — in WordPress use an
 * Accordion / FAQ block and the same text.
 */

export type Faq = { q: string; a: string };

export const FAQS: Faq[] = [
  {
    q: "What plumbing services do you offer?",
    a: "Relied Services offers residential and commercial plumbing, including emergency repairs, pipe repair, drain cleaning, water heater installation, plumbing installations, repairs and maintenance. Our online booking page also lists repiping services, water meter repair, sewer clogs, and water damage & restoration.",
  },
  {
    q: "Do you handle residential and commercial plumbing?",
    a: "Yes. We serve both homeowners and business owners. Our residential services range from routine maintenance to repairs, and our commercial plumbing services are tailored to the needs of business and commercial properties.",
  },
  {
    q: "Can I request emergency plumbing assistance?",
    a: SITE.emergency247Verified
      ? `Yes. We provide emergency plumbing services around the clock for urgent issues such as a burst pipe, a clogged drain, or a water leak. Call ${SITE.phoneDisplay} to describe the situation.`
      : `Yes. Relied Services provides emergency plumbing services for urgent issues such as a burst pipe, a clogged drain, or a water leak. For an urgent problem, call ${SITE.phoneDisplay} so we can talk through the situation and confirm availability.`,
  },
  {
    q: "How do I schedule a plumbing service?",
    a: `You can book online through our booking page, call ${SITE.phoneDisplay}, or send us a message using the contact form. Online booking is handled on our existing booking page, where you can choose the service you need.`,
  },
  {
    q: "How can I contact Relied Services?",
    a: `Call ${SITE.phoneDisplay}, email ${SITE.email}, or use the contact form on this website. We are located in ${SITE.locationShort} and serve the Greater Atlanta area.`,
  },
  {
    q: "What areas do you serve?",
    a: `Relied Services is based in ${SITE.locationLong} and serves residential and commercial clients throughout ${SITE.serviceArea}. If you are not sure whether we serve your location, call ${SITE.phoneDisplay}.`,
  },
  {
    q: "Are you licensed and insured?",
    a: `Relied Services describes itself as a licensed and insured plumbing company, with specialized plumbing and water restoration licenses. If you would like to confirm license details before your service, please call ${SITE.phoneDisplay}.`,
  },
];

/**
 * ============================================================================
 *  BEFORE & AFTER PROJECTS
 * ============================================================================
 *  The current website has no authentic before/after photo pairs, so every
 *  item below is a clearly-labelled SAMPLE PLACEHOLDER using illustrative
 *  stock photos. Nothing here depicts completed Relied Services work.
 *
 *  TO ADD A REAL PROJECT:
 *   1. Save two photos with the SAME framing/aspect ratio (4:3 works best)
 *      into /public/projects/  e.g. bathroom-real-before.jpg
 *   2. Replace `before.src` and `after.src` with the real filenames
 *      and rewrite `alt` to describe the real work
 *   3. Rewrite `caption` with the real project description — the
 *      "Illustrative example" label disappears automatically when `isSample`
 *      is removed or set to false.
 *
 *  In WordPress: create a "Project" custom post type with two image fields
 *  (Before / After), a category, and a caption; render with a Loop Grid and an
 *  image-comparison widget (Elementor: "Before After Slider" add-ons).
 */

export type ProjectIcon = "bath" | "kitchen" | "heater" | "pipe" | "drain" | "fixture";

export type ProjectImage = { src: string; alt: string };

export type Project = {
  id: string;
  title: string;
  category: string;
  icon: ProjectIcon;
  caption: string;
  serviceSlug: string;
  before?: ProjectImage;
  after?: ProjectImage;
  isSample?: boolean;
};

export const PROJECT_CATEGORIES = [
  "Bathroom",
  "Kitchen",
  "Water Heaters",
  "Pipe & Leak Repair",
  "Drainage",
  "Fixtures",
] as const;

export const PROJECTS: Project[] = [
  {
    id: "bathroom-plumbing-upgrade",
    title: "Bathroom Plumbing Upgrade",
    category: "Bathroom",
    icon: "bath",
    caption: "A worn bathroom faucet with visible mineral buildup replaced with a clean chrome fixture.",
    serviceSlug: "residential-plumbing",
    isSample: true,
    before: {
      src: "/projects/bathroom-before.jpg",
      alt: "Illustrative sample: vintage faucet with dripping water and visible wear",
    },
    after: {
      src: "/projects/bathroom-after.jpg",
      alt: "Illustrative sample: modern chrome single-handle bathroom faucet on a white sink",
    },
  },
  {
    id: "kitchen-plumbing-installation",
    title: "Kitchen Plumbing Installation",
    category: "Kitchen",
    icon: "kitchen",
    caption: "A stained kitchen faucet swapped for a clean stainless-steel faucet in a modern setting.",
    serviceSlug: "residential-plumbing",
    isSample: true,
    before: {
      src: "/projects/kitchen-before.jpg",
      alt: "Illustrative sample: rusty kitchen faucet with stained tiles",
    },
    after: {
      src: "/projects/kitchen-after.jpg",
      alt: "Illustrative sample: new stainless-steel kitchen faucet against a marble backsplash",
    },
  },
  {
    id: "water-heater-replacement",
    title: "Water Heater Replacement",
    category: "Water Heaters",
    icon: "heater",
    caption: "An older water heater with visible wear replaced with a tidy, updated unit.",
    serviceSlug: "water-heater-installation",
    isSample: true,
    before: {
      src: "/projects/heater-before.jpg",
      alt: "Illustrative sample: older water heater in a utility area",
    },
    after: {
      src: "/projects/heater-after.jpg",
      alt: "Illustrative sample: clean white water heater installed in a finished interior",
    },
  },
  {
    id: "pipe-and-leak-repair",
    title: "Pipe & Leak Repair",
    category: "Pipe & Leak Repair",
    icon: "pipe",
    caption: "A leaking pipe addressed with a clean new connection and properly fitted joints.",
    serviceSlug: "pipe-repair",
    isSample: true,
    before: {
      src: "/projects/pipe-before.jpg",
      alt: "Illustrative sample: leaking water pipe showing wear",
    },
    after: {
      src: "/projects/pipe-after.jpg",
      alt: "Illustrative sample: plumber's hands installing new steel pipe fittings",
    },
  },
  {
    id: "drainage-improvement",
    title: "Drainage Improvement",
    category: "Drainage",
    icon: "drain",
    caption: "An old stained drain line replaced with clean, properly fitted piping.",
    serviceSlug: "drain-cleaning",
    isSample: true,
    before: {
      src: "/projects/drain-before.jpg",
      alt: "Illustrative sample: aged metal drain spout with water stains",
    },
    after: {
      src: "/projects/drain-after.jpg",
      alt: "Illustrative sample: freshly fitted PVC and metal drain piping",
    },
  },
  {
    id: "fixture-replacement",
    title: "Fixture Installation & Replacement",
    category: "Fixtures",
    icon: "fixture",
    caption: "A worn fixture replaced with a modern, clean bathroom installation.",
    serviceSlug: "residential-plumbing",
    isSample: true,
    before: {
      src: "/projects/fixture-before.jpg",
      alt: "Illustrative sample: row of worn ceramic toilets in an older bathroom",
    },
    after: {
      src: "/projects/fixture-after.jpg",
      alt: "Illustrative sample: modern white toilet and bidet installed on a white tile wall",
    },
  },
];

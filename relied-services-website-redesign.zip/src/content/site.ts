/**
 * ============================================================================
 *  RELIED SERVICES — GLOBAL SITE SETTINGS  (edit here, updates everywhere)
 * ============================================================================
 *  Phone, email, booking link, Google links, hours and service area all live
 *  in this one file. In WordPress these correspond to a single "Site Settings"
 *  area (e.g. ACF Options page, Elementor Dynamic Tags, or a Site Identity /
 *  Global Settings block pattern).
 */

export const SITE = {
  name: "Relied Services",
  legalName: "Relied Services, LLC", // from the footer of the current website
  tagline: "Residential & Commercial Plumbing",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.reliedservices.com",

  // --- Contact (verified: current website) ---------------------------------
  phoneDisplay: "470-430-3022",
  phoneHref: "tel:+14704303022",
  email: "help@reliedservices.com",
  locationShort: "Mableton, GA",
  locationLong: "Mableton, Georgia",
  serviceArea: "Mableton and the Greater Atlanta area",
  // NOTE: no street address is published by the business, so none is shown.

  // --- Booking (verified) -----------------------------------------------------
  // The current site's "Book Online" nav item AND its "Schedule Emergency
  // Service" button both point to this Wix Bookings page. If the booking page
  // moves when the site is migrated to WordPress, change ONLY this line.
  bookingUrl: "https://www.reliedservices.com/book-online",

  // --- Google Business Profile -----------------------------------------------
  googleProfileUrl: "https://maps.app.goo.gl/XSReipg1ASXSG6ZT8",

  // Google "write a review" link. Google's official format is
  //   https://search.google.com/local/writereview?placeid=<PLACE_ID>
  // The Place ID below was derived from the business's own Google Maps listing
  // (the maps.app.goo.gl link resolves to feature id
  //  0x828aebbe986c841b:0x5906445933d19b9b). ⚠ OWNER: click "Leave a Google
  // Review" once while signed in to Google to confirm it opens the review box.
  // If it does not, paste the "Get more reviews" share link from your Google
  // Business Profile dashboard here instead.
  googleReviewUrl:
    "https://search.google.com/local/writereview?placeid=ChIJG4RsmL7rioIRm5vRM1lEBlk",

  // Coordinates of the verified Google Business Profile pin (used only for the map embed).
  map: { lat: 33.819612, lng: -84.558469, zoom: 11 },

  // --- Hours (as shown on the current website) --------------------------------
  hours: [
    { days: "Monday – Friday", time: "8:00 am – 5:00 pm" },
    { days: "Saturday", time: "8:00 am – 1:00 pm" },
  ],

  /**
   * ⚠ OWNER VERIFICATION REQUIRED
   * The current website says "24/7 emergency response", but its own business
   * hours list Mon–Fri 8–5 and Sat 8–1. Until you confirm 24/7 availability is
   * still accurate, the new site does NOT claim it. Set this to true to
   * switch the 24/7 wording on across the site.
   */
  emergency247Verified: false,
} as const;

/** Wording that adapts automatically to the 24/7 flag above. */
export const EMERGENCY_LABEL = SITE.emergency247Verified
  ? "24/7 Emergency Plumbing"
  : "Emergency Plumbing Assistance";

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Services", href: "/services", hasMenu: true },
  { label: "Projects", href: "/projects" },
  { label: "Reviews", href: "/reviews" },
  { label: "FAQs", href: "/faqs" },
  { label: "Contact", href: "/contact" },
] as const;

/**
 * "Service Needed" choices on the contact form.
 * Taken from the services listed on the current online booking page.
 */
export const SERVICE_OPTIONS = [
  "Emergency Plumbing",
  "General Plumbing Services",
  "Residential Plumbing",
  "Commercial Plumbing",
  "Water Heater Installation / Replacement",
  "Pipe Repair / Busted Pipe",
  "Repiping Services",
  "Water Meter Repair",
  "Clogged Drain / Drain Cleaning",
  "Sewer Clog",
  "Water Damage & Restoration",
  "Other / Not Sure",
] as const;

export const LEGAL_UPDATED = "October 2026";

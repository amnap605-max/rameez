# Relied Services — Owner Checklist & WordPress Guide

This site is built with Next.js (not WordPress). **It is not automatically
editable in WordPress and there is no one-click export.** What it *does* give
you is a design system, copy, and structure organised so that rebuilding in
WordPress (Elementor or the native block editor) is quick and mechanical — and
every editable item lives in one clearly-named place.

---

## 1. ⚠ Verify before publishing (owner checklist)

| # | Item | Where | Why |
|---|------|-------|-----|
| 1 | **24/7 emergency claim** | `emergency247Verified` in `src/content/site.ts` | Old site says "24/7 emergency response" but lists hours Mon–Fri 8–5 & Sat 8–1. The new site does **not** claim 24/7 until you set this to `true`. |
| 2 | **Business hours** | `SITE.hours` | Copied from the old site; confirm they're current. |
| 3 | **"Licensed and insured" / "over five years of experience"** | `AboutSection.tsx`, `faqs.ts` | Taken from the old About text. Confirm still accurate (and be ready to show license numbers if asked). |
| 4 | **Booking URL** | `SITE.bookingUrl` | Verified: the old site's "Book Online" and "Schedule Emergency Service" both go to `https://www.reliedservices.com/book-online` (Wix Bookings). **If this domain moves to the new site, that URL will stop pointing at the Wix booking page** — change this one line (or keep a booking page at that path). |
| 5 | **"Leave a Google Review" link** | `SITE.googleReviewUrl` | Derived from your Google listing's own ID in Google's official `writereview?placeid=` format. Click it once (signed in to Google) to confirm it opens the review box. If not, paste the "Share review form" link from your Google Business Profile dashboard. |
| 6 | **Before/After photos** | `src/content/projects.ts` | The old site has **no real before/after pairs**, so all six items are clearly labelled *sample placeholders*. Add real photos (steps in the file header). |
| 7 | **Stock imagery** | `/public/images/svc-*.jpg` | Service-card photos are the old site's plumbing photos plus Pexels stock (commercial, water heater). They illustrate services; they are **not** presented as your projects. Replace with your own work photos when available. |
| 8 | **Privacy Policy / Accessibility Statement** | `/privacy-policy`, `/accessibility` | Sensible starting text written to match how this site works. Have it reviewed against your own practices/legal advice. |
| 9 | **Facebook** | — | The old site's Facebook icon pointed to `facebook.com/wix` (a template placeholder), so it was **not** carried over. Add your real page if you have one. |
| 10 | **Testimonials** | `src/content/reviews.ts` | Three real testimonials from the old site, wording preserved ("Pasty Stewart" spelled as shown; one stray "\|" corrected to "I"). No stars/ratings/counts are displayed because none are published. |
| 11 | **Blog** | — | The old blog is empty ("Check back soon"), so it was not carried over. |

## 1b. Homepage concepts A and B (client review)

Two homepage concepts are live, sharing the same header, footer, palette and
verified content:

| Concept | URL | Layout language |
|---|---|---|
| **A** (original) | `/` | Layered split hero, image service cards, white gallery band, white review cards, full-width photo booking CTA |
| **B** | `/b` | Full-bleed hero photo, editorial numbered service list, dark navy gallery band, navy review cards, two-panel navy/red booking CTA, sticky-sidebar FAQ |

* A small floating **"Preview · Concept A / Concept B"** switcher appears
  bottom-right so reviewers can flip between them (it hides itself on
  `/admin`). **Remove it before launch:** delete the two commented
  `DesignSwitcher` lines in `src/app/layout.tsx`.
* Delete the concept you don't want: `src/app/b/page.tsx` +
  `src/components/sections/variantB.tsx` (Concept B), then keep A at `/`.
* `/b` is set to `noindex, nofollow` so it never competes with the homepage in
  search results. `/a` simply redirects to `/`.

## 2. Where to edit things (this codebase)

| Want to change… | Edit |
|---|---|
| Phone, email, booking URL, Google links, hours, map pin | `src/content/site.ts` |
| Colors | `src/app/globals.css` (`@theme` block) |
| Service cards / service pages | `src/content/services.ts` |
| Before & After gallery | `src/content/projects.ts` + images in `public/projects/` |
| Testimonials | `src/content/reviews.ts` |
| FAQs | `src/content/faqs.ts` |
| Contact form "Service Needed" list | `SERVICE_OPTIONS` in `site.ts` |

## 3. Contact form destination

Every submission is validated on the server, spam-filtered (hidden honeypot
field, minimum-fill-time check, per-visitor and global rate limits), and saved
to the PostgreSQL `inquiries` table. Raw IP addresses are never stored.

* **View leads:** `/admin/inquiries?key=<ADMIN_ACCESS_KEY>` (key is in `.env`).
* **Email each lead to you:** set `RESEND_API_KEY` and `INQUIRY_TO_EMAIL`
  (optional `INQUIRY_FROM_EMAIL` — must be a domain verified with Resend).
* **Send to a CRM / Zapier / Make:** set `INQUIRY_WEBHOOK_URL` (receives JSON).
* Payment details are never collected.

## 4. Rebuilding in WordPress (Elementor or Block Editor)

### Global settings (do this first)
**Global Colors** — create exactly these:

| Name | Hex | Used for |
|---|---|---|
| Primary Navy | `#0B1F3A` | Header, footer, hero, headings |
| Deep Navy | `#07152B` | Hero/footer backgrounds, mobile bar |
| Secondary Navy | `#163A63` | Hover, secondary surfaces |
| Action Red | `#D9272E` | Primary buttons, accent lines, key icons |
| Action Red (hover) | `#B51E25` | Button hover |
| White | `#FFFFFF` | Cards, clean backgrounds |
| Light Background | `#F4F7FB` | Alternating sections |
| Body Text | `#283548` | Paragraph text |

**Global Fonts:** Headings — *Montserrat* 700/800; Body — *Inter* 400/500/600.
**Buttons:** define two global button styles — *Primary* (red, white text, 8px
radius, 48px min height) and *Secondary* (white or outlined).
**Spacing:** sections use 80–96px vertical padding (desktop), 64–80px (mobile);
content width 1280px.

### Page → section map (build each as a reusable template / pattern)

| Section (component file) | WordPress build |
|---|---|
| Header (`layout/Header.tsx`) | Header template: logo, nav menu with *Services* submenu, red "Call Now" button (`tel:+14704303022`), "Book Service" button |
| Hero (`sections/Hero.tsx`) | Container (2 columns): heading, text, icon list, 3 buttons \| image |
| Trust strip (`TrustStrip.tsx`) | Icon-box row (4) |
| Services (`ServicesSection`, `ServiceCard`) | **Custom Post Type "Service"** + Loop Grid/Query Loop (3 cols) with image, title, excerpt, "Learn More" |
| Service pages | Single-post template for "Service": hero, overview, checklist, CTA box, related services |
| Before/After (`gallery/*`) | **CPT "Project"** with fields *Before image*, *After image*, *Category*, *Caption* (ACF/Meta Box) + an image-comparison widget (e.g. Elementor "Image Comparison"/"Before After Slider" add-on) inside a Loop Grid; category filter via taxonomy |
| About (`AboutSection`) | Container 2-col: image \| text + button |
| Why Choose Us | Navy container with Icon Box ×5 |
| Reviews (`ReviewsSection`) | **CPT "Testimonial"** + Loop Grid; two buttons to the Google links |
| Booking CTA (`BookingCta`) | Container with background image + overlay |
| FAQ (`FaqSection`) | Accordion/FAQ block (enable FAQ schema in your SEO plugin) |
| Service area + map | Text + Google Maps embed (use the pin from your Google Business Profile) |
| Contact form (`ContactForm`) | WPForms / Gravity Forms / Fluent Forms with the same 7 fields; enable honeypot + reCAPTCHA/Turnstile; route notifications to help@reliedservices.com |
| Footer | Footer template, 4 columns (brand / services / company / contact) |
| Mobile call bar | Sticky bottom container shown on mobile only |

### Store the shared values once
Create an options page (ACF Options, or Elementor Dynamic Tags) with: phone,
email, booking URL, Google Business Profile URL, Google review URL, hours,
service-area text. Reference these from every button and footer so each only
needs editing in one place.

## 5. Images
* Rod's photos: `hero-plumber.jpg`, `about-plumber.jpg` (original files from
  your current site, resized/compressed).
* All images are pre-compressed (≈55–200 KB). In WordPress, upload at the same
  sizes and add an image-optimization plugin (e.g. ShortPixel / Imagify / WebP).
